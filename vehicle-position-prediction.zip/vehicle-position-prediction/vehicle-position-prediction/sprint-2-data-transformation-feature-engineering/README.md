# Sprint 2: Data Transformation & Feature Engineering (Days 6–10)

**Objective**: Transform raw data into features for model training.

## Data Team
1. Use dbt to create schemas for historical trips, zones, and revenue.
2. Python scripts to compute demand per zone/hour and vehicle availability.
3. Store features in Feast (Feature Store).

## Operational Team
1. FastAPI endpoint to expose transformed features for model training.
2. Set up MLflow to log and track feature engineering steps.

## Technologies
dbt · Python · Pandas · Feast · FastAPI · MLflow

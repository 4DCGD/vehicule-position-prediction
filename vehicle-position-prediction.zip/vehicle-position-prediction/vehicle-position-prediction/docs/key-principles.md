# Key Principles

1. **Pair programming** — pair data team with operational team to share knowledge.
2. **Mentorship** — assign a senior developer to guide complex tasks (e.g. MLflow setup).
3. **Iterative feedback** — review progress after each sprint and adjust as needed.

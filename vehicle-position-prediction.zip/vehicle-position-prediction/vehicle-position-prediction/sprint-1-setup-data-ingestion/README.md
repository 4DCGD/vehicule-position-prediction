# Sprint 1: Setup & Data Ingestion (Days 1–5)

**Objective**: Establish infrastructure and ingest raw data.

## Data Team
1. Set up MinIO/S3 and PostgreSQL + PostGIS for spatial data.
2. Configure Kafka/Redpanda for real-time GPS/telemetry ingestion.
3. Python script to store raw data (bookings, GPS, weather) in MinIO and PostgreSQL.

## Operational Team
1. Spring Boot microservice to expose booking data (mock/dummy).
2. Set up Redis for caching vehicle telemetry.

## Technologies
MinIO/S3 · PostgreSQL + PostGIS · Kafka/Redpanda · Redis · Spring Boot

# Sprint 4: Decision Engine & UI (Days 16–20)

**Objective**: Build the decision engine and user-facing tools.

## Data Team
1. Decision engine (Spring Boot microservice) — recommend vehicle positions from predicted demand.
2. Integrate model API to compute optimal zones.

## Operational Team
1. React/Next.js dashboard — display predicted positions and recommendations.
2. Flutter mobile app — fleet availability and relocation suggestions.

## Technologies
Spring Boot · FastAPI · React/Next.js · Flutter

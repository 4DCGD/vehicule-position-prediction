# Vehicle Position Prediction MVP

## Use Case
Predict where each vehicle should be in the next 2, 6, and 24 hours to maximize revenue and availability.

## Inputs
Bookings · GPS Data · Weather · Events · Traffic · Vehicle Telemetry

## Outputs
- Predicted vehicle locations per zone (2h / 6h / 24h)
- Recommended actions for fleet relocation

## Core Stack
- PostgreSQL + PostGIS
- Kafka or Redpanda
- MinIO
- Python + XGBoost
- MLflow
- FastAPI
- React dashboard

## Sprint Overview
| Sprint | Days  | Focus                                    |
|--------|-------|------------------------------------------|
| 1      | 1–5   | Setup & Data Ingestion                   |
| 2      | 6–10  | Data Transformation & Feature Engineering|
| 3      | 11–15 | Model Training & Registry                |
| 4      | 16–20 | Decision Engine & UI                     |
| 5      | 21–25 | Testing & Optimization                   |

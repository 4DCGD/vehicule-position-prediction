# Sprint 3: Model Training & Registry (Days 11–15)

**Objective**: Train a demand forecasting model and register it.

## Data Team
1. Train an XGBoost model to predict demand per zone/hour.
2. Log model metrics and artifacts in MLflow.
3. Save trained model in the MLflow Model Registry.

## Operational Team
1. FastAPI endpoint to serve the model (predict demand 2h / 6h / 24h).
2. Test with sample inputs and validate output.

## Technologies
Python · XGBoost · scikit-learn · MLflow · FastAPI

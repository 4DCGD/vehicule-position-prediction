"""
Sprint 3 – Demand Forecasting Model Training
Trains XGBoost models for 2h, 6h, and 24h demand horizons.
Logs all experiments and registers best models to MLflow.
"""

import os
import logging
import warnings
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb

try:
    import mlflow
    import mlflow.xgboost
    from mlflow.models.signature import infer_signature
    HAS_MLFLOW = True
except ImportError:
    HAS_MLFLOW = False

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

MLFLOW_URI     = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")
EXPERIMENT     = os.getenv("MLFLOW_EXPERIMENT",   "vpp-demand-forecasting")
DATA_PATH      = os.getenv("FEATURE_DATA_PATH",   "data/zone_demand_features.parquet")
MODEL_DIR      = os.getenv("MODEL_DIR", "models")
HORIZONS       = [2, 6, 24]   # hours ahead to predict
USE_MLFLOW     = os.getenv("USE_MLFLOW", "auto")  # auto | true | false

FEATURE_COLS = [
    "trip_count", "rolling_7d_avg_trips", "demand_momentum",
    "revenue_efficiency", "hour_sin", "hour_cos",
    "dow_sin", "dow_cos", "is_peak_hour", "is_weekend",
    "available_vehicles", "zone_encoded",
]

# XGBoost hyperparameter search space
PARAM_GRID = [
    {"n_estimators": 200, "max_depth": 5, "learning_rate": 0.05, "subsample": 0.8},
    {"n_estimators": 300, "max_depth": 6, "learning_rate": 0.03, "subsample": 0.7},
    {"n_estimators": 150, "max_depth": 4, "learning_rate": 0.1,  "subsample": 0.9},
]


def _mlflow_enabled() -> bool:
    if USE_MLFLOW == "false":
        return False
    if USE_MLFLOW == "true":
        return HAS_MLFLOW
    if not HAS_MLFLOW:
        return False
    try:
        mlflow.set_tracking_uri(MLFLOW_URI)
        mlflow.get_experiment_by_name(EXPERIMENT)
        return True
    except Exception:
        return False


def load_data(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        log.warning("Feature file not found at %s — generating synthetic data", path)
        from generate_synthetic_data import generate
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        generate().to_parquet(path, index=False)
    df = pd.read_parquet(path)
    le = LabelEncoder()
    df["zone_encoded"] = le.fit_transform(df["zone_code"])
    df = df.sort_values("event_timestamp")
    return df, le


def create_target(df: pd.DataFrame, horizon_hours: int) -> pd.Series:
    """Shift trip_count by horizon to create future demand label."""
    return df.groupby("zone_code")["trip_count"].shift(-horizon_hours)


def evaluate(y_true, y_pred) -> dict:
    return {
        "mae":  mean_absolute_error(y_true, y_pred),
        "rmse": np.sqrt(mean_squared_error(y_true, y_pred)),
        "r2":   r2_score(y_true, y_pred),
    }


def train_for_horizon(df: pd.DataFrame, horizon_hours: int, le: LabelEncoder):
    log.info("Training model for %dh horizon…", horizon_hours)

    target = create_target(df, horizon_hours)
    mask   = target.notna()
    X      = df.loc[mask, FEATURE_COLS]
    y      = target[mask]

    tscv   = TimeSeriesSplit(n_splits=5)
    best_run_id = None
    best_mae    = float("inf")

    use_mlflow = _mlflow_enabled()
    best_model = None

    for params in PARAM_GRID:
        run_ctx = mlflow.start_run(run_name=f"xgb_{horizon_hours}h_n{params['n_estimators']}") if use_mlflow else _nullcontext()
        with run_ctx as run:
            if use_mlflow:
                mlflow.log_params({**params, "horizon_hours": horizon_hours})

            fold_metrics = []
            for fold, (train_idx, val_idx) in enumerate(tscv.split(X)):
                X_tr, X_val = X.iloc[train_idx], X.iloc[val_idx]
                y_tr, y_val = y.iloc[train_idx], y.iloc[val_idx]

                model = xgb.XGBRegressor(
                    **params,
                    objective="reg:squarederror",
                    tree_method="hist",
                    random_state=42,
                    early_stopping_rounds=20,
                    eval_metric="mae",
                )
                model.fit(X_tr, y_tr,
                          eval_set=[(X_val, y_val)],
                          verbose=False)
                preds = model.predict(X_val)
                fold_metrics.append(evaluate(y_val, preds))

            avg_metrics = {
                k: np.mean([m[k] for m in fold_metrics])
                for k in fold_metrics[0]
            }
            if use_mlflow:
                mlflow.log_metrics(avg_metrics)
            log.info("  Horizon %dh | params=%s | MAE=%.3f RMSE=%.3f R2=%.3f",
                     horizon_hours, params, avg_metrics["mae"],
                     avg_metrics["rmse"], avg_metrics["r2"])

            final_model = xgb.XGBRegressor(**params,
                                            objective="reg:squarederror",
                                            tree_method="hist",
                                            random_state=42)
            final_model.fit(X, y)

            if use_mlflow:
                signature = infer_signature(X, final_model.predict(X))
                mlflow.xgboost.log_model(
                    final_model, "model",
                    signature=signature,
                    input_example=X.head(3),
                    registered_model_name=f"vpp-demand-{horizon_hours}h",
                )

            if avg_metrics["mae"] < best_mae:
                best_mae    = avg_metrics["mae"]
                best_run_id = run.info.run_id if use_mlflow and run else f"local_{horizon_hours}h"
                best_model  = final_model

    if best_model is not None:
        Path(MODEL_DIR).mkdir(parents=True, exist_ok=True)
        model_path = Path(MODEL_DIR) / f"vpp-demand-{horizon_hours}h.pkl"
        with open(model_path, "wb") as f:
            pickle.dump({"model": best_model, "label_encoder": le}, f)
        log.info("Saved local model to %s", model_path)

    return best_run_id, best_mae


class _nullcontext:
    def __enter__(self):
        self.info = type("Info", (), {"run_id": "local"})()
        return self
    def __exit__(self, *args):
        pass


def run():
    if _mlflow_enabled():
        mlflow.set_tracking_uri(MLFLOW_URI)
        mlflow.set_experiment(EXPERIMENT)
    else:
        log.warning("MLflow unavailable — training with local model export only")

    log.info("Loading feature data from %s…", DATA_PATH)
    df, le = load_data(DATA_PATH)
    log.info("Loaded %d rows across %d zones", len(df), df["zone_code"].nunique())

    results = {}
    for horizon in HORIZONS:
        run_id, mae = train_for_horizon(df, horizon, le)
        results[horizon] = {"run_id": run_id, "best_mae": mae}

    log.info("\n── Training Summary ──")
    for h, r in results.items():
        log.info("  %2dh horizon | best MAE=%.3f | run_id=%s", h, r["best_mae"], r["run_id"])


if __name__ == "__main__":
    run()

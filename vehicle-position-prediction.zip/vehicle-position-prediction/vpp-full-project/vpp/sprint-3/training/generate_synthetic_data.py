"""
Generate synthetic training data when PostgreSQL is unavailable.
Produces data/zone_demand_features.parquet with realistic demand patterns.
"""

import os
import numpy as np
import pandas as pd

ZONES = ["IST-001", "IST-002", "IST-003", "IST-004", "IST-005", "IST-006"]
OUTPUT = os.getenv("FEATURE_DATA_PATH", "data/zone_demand_features.parquet")
HOURS = 30 * 24  # 30 days hourly


def generate() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    rows = []
    base_time = pd.Timestamp("2024-01-01", tz="UTC")

    for h in range(HOURS):
        ts = base_time + pd.Timedelta(hours=h)
        dow = ts.dayofweek
        hour = ts.hour
        is_weekend = int(dow >= 5)
        is_peak = int(hour in (7, 8, 9, 17, 18, 19, 20))

        for zi, zone in enumerate(ZONES):
            base_demand = 8 + zi * 0.5
            if is_peak:
                base_demand *= 1.8
            if is_weekend:
                base_demand *= 1.2
            trip_count = max(0, base_demand + rng.normal(0, 2))
            rolling = base_demand + rng.normal(0, 1)

            rows.append({
                "zone_code": zone,
                "hour_bucket": ts,
                "day_of_week": dow,
                "hour_of_day": hour,
                "trip_count": round(trip_count, 1),
                "unique_vehicles": int(rng.integers(1, 5)),
                "total_revenue": round(trip_count * rng.uniform(8, 25), 2),
                "avg_revenue": round(rng.uniform(8, 25), 2),
                "avg_duration_min": round(rng.uniform(15, 50), 1),
                "avg_distance_km": round(rng.uniform(2, 15), 2),
                "rolling_7d_avg_trips": round(rolling, 2),
                "rolling_7d_avg_revenue": round(rolling * 15, 2),
                "hour_sin": np.sin(2 * np.pi * hour / 24),
                "hour_cos": np.cos(2 * np.pi * hour / 24),
                "dow_sin": np.sin(2 * np.pi * dow / 7),
                "dow_cos": np.cos(2 * np.pi * dow / 7),
                "demand_momentum": round(trip_count / max(rolling, 0.1), 3),
                "revenue_efficiency": round(rng.uniform(2, 6), 2),
                "is_peak_hour": is_peak,
                "is_weekend": is_weekend,
                "available_vehicles": int(rng.integers(1, 4)),
                "avg_battery_pct": round(rng.uniform(50, 95), 1),
                "event_timestamp": ts,
            })

    return pd.DataFrame(rows)


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUTPUT) or ".", exist_ok=True)
    df = generate()
    df.to_parquet(OUTPUT, index=False)
    print(f"Generated {len(df)} rows -> {OUTPUT}")

"""
Sprint 3 – Model Serving API
FastAPI app that loads trained XGBoost models from MLflow
and serves demand predictions for 2h, 6h, and 24h horizons.
"""

import os
import logging
import pickle
import time
from functools import lru_cache
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

try:
    import mlflow
    import mlflow.pyfunc
    HAS_MLFLOW = True
except ImportError:
    HAS_MLFLOW = False

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

MLFLOW_URI = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")
MODEL_STAGE = os.getenv("MODEL_STAGE", "Production")
MODEL_DIR = os.getenv("MODEL_DIR", "../training/models")

prediction_requests = Counter(
    "vpp_prediction_requests_total", "Total prediction requests", ["horizon", "status"]
)
prediction_latency = Histogram(
    "vpp_prediction_latency_seconds", "Prediction latency", ["horizon"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0],
)

app = FastAPI(
    title="VPP Demand Prediction API",
    description="Predict vehicle demand per zone for 2h, 6h, and 24h horizons",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if HAS_MLFLOW:
    mlflow.set_tracking_uri(MLFLOW_URI)

FEATURE_COLS = [
    "trip_count", "rolling_7d_avg_trips", "demand_momentum",
    "revenue_efficiency", "hour_sin", "hour_cos",
    "dow_sin", "dow_cos", "is_peak_hour", "is_weekend",
    "available_vehicles", "zone_encoded",
]


# ── Model loader (cached) ─────────────────────────────────────
class _LocalModel:
    def __init__(self, model):
        self._model = model

    def predict(self, df: pd.DataFrame):
        return self._model.predict(df)


@lru_cache(maxsize=3)
def get_model(horizon: int):
    name = f"vpp-demand-{horizon}h"
    local_path = Path(MODEL_DIR) / f"{name}.pkl"
    if local_path.exists():
        log.info("Loading local model: %s", local_path)
        with open(local_path, "rb") as f:
            data = pickle.load(f)
        return _LocalModel(data["model"])

    if HAS_MLFLOW:
        uri = f"models:/{name}/{MODEL_STAGE}"
        log.info("Loading MLflow model: %s", uri)
        return mlflow.pyfunc.load_model(uri)

    raise FileNotFoundError(
        f"No model found for {horizon}h — run train.py first"
    )


# ── Schemas ───────────────────────────────────────────────────
class PredictionRequest(BaseModel):
    zone_code:             str   = Field(..., example="IST-001")
    zone_encoded:          int   = Field(..., example=0)
    trip_count:            float = Field(..., example=12.0)
    rolling_7d_avg_trips:  float = Field(..., example=10.5)
    demand_momentum:       float = Field(..., example=1.1)
    revenue_efficiency:    float = Field(..., example=4.2)
    hour_sin:              float
    hour_cos:              float
    dow_sin:               float
    dow_cos:               float
    is_peak_hour:          int   = Field(..., ge=0, le=1)
    is_weekend:            int   = Field(..., ge=0, le=1)
    available_vehicles:    float = Field(..., example=3.0)


class ZonePrediction(BaseModel):
    zone_code:     str
    horizon_hours: int
    demand_score:  float
    confidence:    float


class BatchPredictionRequest(BaseModel):
    zones: list[PredictionRequest]
    horizons: list[Literal[2, 6, 24]] = [2, 6, 24]


class BatchPredictionResponse(BaseModel):
    predictions: list[ZonePrediction]
    model_versions: dict[str, str]


# ── Helpers ───────────────────────────────────────────────────
def request_to_df(req: PredictionRequest) -> pd.DataFrame:
    return pd.DataFrame([{col: getattr(req, col, 0) for col in FEATURE_COLS}])


def compute_confidence(pred: float, rolling_avg: float) -> float:
    if rolling_avg == 0:
        return 0.5
    ratio = pred / rolling_avg
    return float(np.clip(1 - abs(ratio - 1) * 0.3, 0.4, 0.99))


# ── Endpoints ─────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/predict/batch", response_model=BatchPredictionResponse)
def predict_batch(req: BatchPredictionRequest):
    predictions = []
    model_versions = {}

    for horizon in req.horizons:
        model = get_model(horizon)
        meta = getattr(model, "metadata", None)
        run_id = getattr(meta, "run_id", "local") if meta else "local"
        model_versions[f"{horizon}h"] = str(run_id)[:8]

        df = pd.DataFrame([
            {col: getattr(z, col, 0) for col in FEATURE_COLS}
            for z in req.zones
        ])
        scores = model.predict(df)

        for zone_req, score in zip(req.zones, scores):
            conf = compute_confidence(score, zone_req.rolling_7d_avg_trips)
            predictions.append(ZonePrediction(
                zone_code=zone_req.zone_code,
                horizon_hours=horizon,
                demand_score=round(max(0, float(score)), 3),
                confidence=round(conf, 3),
            ))

    return BatchPredictionResponse(
        predictions=predictions,
        model_versions=model_versions,
    )


@app.post("/predict/{horizon_hours}", response_model=ZonePrediction)
def predict_single(
    horizon_hours: int,
    req: PredictionRequest,
):
    if horizon_hours not in (2, 6, 24):
        raise HTTPException(status_code=400, detail="horizon_hours must be 2, 6, or 24")
    start = time.perf_counter()
    try:
        model  = get_model(horizon_hours)
        df     = request_to_df(req)
        score  = float(model.predict(df)[0])
        conf   = compute_confidence(score, req.rolling_7d_avg_trips)
        prediction_requests.labels(horizon=str(horizon_hours), status="success").inc()
        return ZonePrediction(
            zone_code=req.zone_code,
            horizon_hours=horizon_hours,
            demand_score=round(max(0, score), 3),
            confidence=round(conf, 3),
        )
    except Exception as e:
        prediction_requests.labels(horizon=str(horizon_hours), status="error").inc()
        log.error("Prediction error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        prediction_latency.labels(horizon=str(horizon_hours)).observe(
            time.perf_counter() - start
        )


@app.get("/models/status")
def model_status():
    status = {}
    for h in [2, 6, 24]:
        try:
            get_model(h)
            status[f"{h}h"] = "loaded"
        except Exception as e:
            status[f"{h}h"] = f"error: {e}"
    return status

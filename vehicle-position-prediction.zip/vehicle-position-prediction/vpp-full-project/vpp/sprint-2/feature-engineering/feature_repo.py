"""
Sprint 2 – Feast Feature Repository
Defines feature views for the ML training and serving pipeline.
"""

from datetime import timedelta
from feast import (
    Entity, FeatureView, Field, FileSource, PushSource,
    FeatureService
)
from feast.types import Float32, Float64, Int64, String

# ── Entities ──────────────────────────────────────────────────
zone = Entity(
    name="zone_code",
    description="City grid zone identifier",
)

# ── Sources ───────────────────────────────────────────────────
zone_demand_push_source = PushSource(
    name="zone_demand_stats_source",
    batch_source=FileSource(
        path="data/zone_demand_features.parquet",
        timestamp_field="event_timestamp",
    ),
)

# ── Feature Views ─────────────────────────────────────────────
zone_demand_fv = FeatureView(
    name="zone_demand_features",
    entities=[zone],
    ttl=timedelta(days=7),
    schema=[
        Field(name="trip_count",            dtype=Int64),
        Field(name="unique_vehicles",        dtype=Int64),
        Field(name="total_revenue",          dtype=Float64),
        Field(name="avg_revenue",            dtype=Float64),
        Field(name="avg_duration_min",       dtype=Float64),
        Field(name="avg_distance_km",        dtype=Float64),
        Field(name="rolling_7d_avg_trips",   dtype=Float64),
        Field(name="rolling_7d_avg_revenue", dtype=Float64),
        Field(name="demand_momentum",        dtype=Float32),
        Field(name="revenue_efficiency",     dtype=Float32),
        Field(name="hour_sin",               dtype=Float32),
        Field(name="hour_cos",               dtype=Float32),
        Field(name="dow_sin",                dtype=Float32),
        Field(name="dow_cos",                dtype=Float32),
        Field(name="is_peak_hour",           dtype=Int64),
        Field(name="is_weekend",             dtype=Int64),
        Field(name="available_vehicles",     dtype=Float64),
        Field(name="avg_battery_pct",        dtype=Float32),
    ],
    source=zone_demand_push_source,
    online=True,
)

# ── Feature Service (what the model API requests) ─────────────
demand_model_features = FeatureService(
    name="demand_prediction_service",
    features=[
        zone_demand_fv[[
            "trip_count", "rolling_7d_avg_trips", "demand_momentum",
            "revenue_efficiency", "hour_sin", "hour_cos",
            "dow_sin", "dow_cos", "is_peak_hour", "is_weekend",
            "available_vehicles",
        ]]
    ],
)

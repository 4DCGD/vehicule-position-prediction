"""
Sprint 2 – Feature Engineering Pipeline
Reads from the dbt mart, computes additional features, and pushes to Feast.
"""

import os
import logging
from datetime import datetime, timedelta, timezone

import pandas as pd
import numpy as np
import psycopg2
from feast import FeatureStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

PG_DSN = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")
FEAST_REPO = os.getenv("FEAST_REPO", "./feature_repo")


# ── Load data from dbt mart ────────────────────────────────────
def load_zone_demand(conn) -> pd.DataFrame:
    query = """
        SELECT
            zone_code,
            hour_bucket,
            day_of_week,
            hour_of_day,
            trip_count,
            unique_vehicles,
            total_revenue,
            avg_revenue,
            avg_duration_min,
            avg_distance_km,
            rolling_7d_avg_trips,
            rolling_7d_avg_revenue
        FROM marts.mart_zone_hourly_demand
        ORDER BY zone_code, hour_bucket
    """
    return pd.read_sql(query, conn, parse_dates=["hour_bucket"])


def load_vehicle_availability(conn) -> pd.DataFrame:
    query = """
        SELECT
            v.current_zone          AS zone_code,
            COUNT(*)                AS available_vehicles,
            AVG(v.battery_pct)      AS avg_battery_pct,
            NOW()                   AS event_timestamp
        FROM vehicles v
        WHERE v.status = 'AVAILABLE'
        GROUP BY v.current_zone
    """
    return pd.read_sql(query, conn)


# ── Feature engineering ────────────────────────────────────────
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add derived features on top of raw aggregates."""
    df = df.copy()

    # Cyclical encoding of hour and day
    df["hour_sin"] = np.sin(2 * np.pi * df["hour_of_day"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour_of_day"] / 24)
    df["dow_sin"]  = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["dow_cos"]  = np.cos(2 * np.pi * df["day_of_week"] / 7)

    # Demand momentum: current vs rolling average
    df["demand_momentum"] = (
        df["trip_count"] / df["rolling_7d_avg_trips"].replace(0, np.nan)
    ).fillna(1.0)

    # Revenue efficiency score
    df["revenue_per_trip"] = df["total_revenue"] / df["trip_count"].replace(0, np.nan)
    df["revenue_efficiency"] = (
        df["revenue_per_trip"] / df["avg_distance_km"].replace(0, np.nan)
    ).fillna(0)

    # Peak-hour flag
    df["is_peak_hour"] = df["hour_of_day"].isin([7, 8, 9, 17, 18, 19, 20]).astype(int)

    # Weekend flag
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)

    # Feast requires an event_timestamp
    df["event_timestamp"] = df["hour_bucket"].dt.tz_localize("UTC")

    return df


# ── Push to Feast ─────────────────────────────────────────────
def push_to_feast(df: pd.DataFrame, store: FeatureStore):
    log.info("Pushing %d feature rows to Feast…", len(df))
    store.push("zone_demand_stats_source", df, to="online_and_offline")
    log.info("Feature push complete.")


# ── Main ──────────────────────────────────────────────────────
def run():
    conn  = psycopg2.connect(PG_DSN)
    store = FeatureStore(repo_path=FEAST_REPO)

    demand_df      = load_zone_demand(conn)
    availability_df = load_vehicle_availability(conn)
    conn.close()

    log.info("Loaded %d demand rows and %d availability rows",
             len(demand_df), len(availability_df))

    features_df = engineer_features(demand_df)

    # Merge availability
    features_df = features_df.merge(
        availability_df[["zone_code", "available_vehicles", "avg_battery_pct"]],
        on="zone_code",
        how="left",
    )
    features_df["available_vehicles"] = features_df["available_vehicles"].fillna(0)

    push_to_feast(features_df, store)

    # Export parquet for ML training
    out_path = os.getenv("FEATURE_DATA_PATH", "../../sprint-3/training/data/zone_demand_features.parquet")
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    features_df.to_parquet(out_path, index=False)
    log.info("Exported training parquet to %s", out_path)

    log.info("Feature engineering pipeline complete — %d features written", len(features_df))


if __name__ == "__main__":
    run()

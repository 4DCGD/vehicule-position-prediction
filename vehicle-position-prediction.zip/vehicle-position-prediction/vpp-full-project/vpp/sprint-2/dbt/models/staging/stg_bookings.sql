-- models/staging/stg_bookings.sql
-- Cleans and standardises raw bookings

with source as (
    select * from {{ source('vpp_raw', 'bookings') }}
),

renamed as (
    select
        id                                          as booking_id,
        vehicle_id,
        user_id,
        pickup_zone,
        dropoff_zone,
        pickup_time                                 as started_at,
        dropoff_time                                as ended_at,
        revenue_usd,
        distance_km,
        status,
        created_at,

        -- derived
        extract(epoch from (dropoff_time - pickup_time)) / 60.0
                                                    as duration_minutes,
        date_trunc('hour', pickup_time)             as pickup_hour,
        extract(dow from pickup_time)               as day_of_week,   -- 0=Sun
        extract(hour from pickup_time)              as hour_of_day

    from source
    where upper(status) = 'COMPLETED'
      and dropoff_time > pickup_time
      and revenue_usd > 0
)

select * from renamed

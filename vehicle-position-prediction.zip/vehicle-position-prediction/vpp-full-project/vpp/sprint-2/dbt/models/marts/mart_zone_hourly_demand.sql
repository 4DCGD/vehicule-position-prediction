-- models/marts/mart_zone_hourly_demand.sql
-- Aggregated demand features per zone per hour — fed directly into Feature Store

with bookings as (
    select * from {{ ref('stg_bookings') }}
),

zone_hour_agg as (
    select
        pickup_zone                         as zone_code,
        pickup_hour                         as hour_bucket,
        day_of_week,
        hour_of_day,

        -- demand signals
        count(*)                            as trip_count,
        count(distinct vehicle_id)          as unique_vehicles,

        -- revenue signals
        sum(revenue_usd)                    as total_revenue,
        avg(revenue_usd)                    as avg_revenue,
        percentile_cont(0.5) within group (order by revenue_usd)
                                            as median_revenue,

        -- trip characteristics
        avg(duration_minutes)               as avg_duration_min,
        avg(distance_km)                    as avg_distance_km

    from bookings
    group by
        pickup_zone,
        pickup_hour,
        day_of_week,
        hour_of_day
),

-- 7-day rolling averages for trend features
with_rolling as (
    select
        *,
        avg(trip_count) over (
            partition by zone_code, hour_of_day, day_of_week
            order by hour_bucket
            rows between 6 preceding and current row
        )                                   as rolling_7d_avg_trips,
        avg(total_revenue) over (
            partition by zone_code, hour_of_day, day_of_week
            order by hour_bucket
            rows between 6 preceding and current row
        )                                   as rolling_7d_avg_revenue
    from zone_hour_agg
)

select * from with_rolling
order by zone_code, hour_bucket

"""
Export engineered features to parquet for ML training.
Runs feature engineering logic and writes data/zone_demand_features.parquet.

Usage:
    python scripts/export_features.py
"""

import os
import sys
import logging

import numpy as np
import pandas as pd
import psycopg2

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

PG_DSN = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")
OUTPUT = os.getenv("FEATURE_DATA_PATH", "sprint-3/training/data/zone_demand_features.parquet")


def load_zone_demand(conn) -> pd.DataFrame:
    query = """
        SELECT
            zone_code, hour_bucket, day_of_week, hour_of_day,
            trip_count, unique_vehicles, total_revenue, avg_revenue,
            avg_duration_min, avg_distance_km,
            rolling_7d_avg_trips, rolling_7d_avg_revenue
        FROM marts.mart_zone_hourly_demand
        ORDER BY zone_code, hour_bucket
    """
    return pd.read_sql(query, conn, parse_dates=["hour_bucket"])


def load_vehicle_availability(conn) -> pd.DataFrame:
    query = """
        SELECT current_zone AS zone_code,
               COUNT(*) AS available_vehicles,
               AVG(battery_pct) AS avg_battery_pct
        FROM vehicles
        WHERE status = 'AVAILABLE'
        GROUP BY current_zone
    """
    return pd.read_sql(query, conn)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["hour_sin"] = np.sin(2 * np.pi * df["hour_of_day"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour_of_day"] / 24)
    df["dow_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["dow_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7)
    df["demand_momentum"] = (
        df["trip_count"] / df["rolling_7d_avg_trips"].replace(0, np.nan)
    ).fillna(1.0)
    df["revenue_per_trip"] = df["total_revenue"] / df["trip_count"].replace(0, np.nan)
    df["revenue_efficiency"] = (
        df["revenue_per_trip"] / df["avg_distance_km"].replace(0, np.nan)
    ).fillna(0)
    df["is_peak_hour"] = df["hour_of_day"].isin([7, 8, 9, 17, 18, 19, 20]).astype(int)
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    df["event_timestamp"] = pd.to_datetime(df["hour_bucket"], utc=True)
    return df


def run():
    conn = psycopg2.connect(PG_DSN)
    demand_df = load_zone_demand(conn)
    availability_df = load_vehicle_availability(conn)
    conn.close()

    if demand_df.empty:
        log.error("No mart data — run bootstrap_data.py first")
        sys.exit(1)

    features_df = engineer_features(demand_df)
    features_df = features_df.merge(
        availability_df, on="zone_code", how="left"
    )
    features_df["available_vehicles"] = features_df["available_vehicles"].fillna(0)

    os.makedirs(os.path.dirname(OUTPUT) or ".", exist_ok=True)
    features_df.to_parquet(OUTPUT, index=False)
    log.info("Exported %d feature rows to %s", len(features_df), OUTPUT)


if __name__ == "__main__":
    run()

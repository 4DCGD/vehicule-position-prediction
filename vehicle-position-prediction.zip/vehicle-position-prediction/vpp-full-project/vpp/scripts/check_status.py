"""Quick health check for all VPP services."""
import math
import requests
from datetime import datetime

print("=== VPP Full Stack Status ===\n")

checks = [
    ("Model API",    "http://127.0.0.1:8000/health"),
    ("Booking API",  "http://127.0.0.1:8081/api/v1/vehicles"),
    ("Decision API", "http://127.0.0.1:8082/actuator/health"),
    ("Dashboard",    "http://127.0.0.1:5173"),
]
for name, url in checks:
    try:
        r = requests.get(url, timeout=5)
        print(f"  {name:16} OK ({r.status_code})")
    except Exception as e:
        print(f"  {name:16} FAIL - {e}")

vehicles = requests.get("http://127.0.0.1:8081/api/v1/vehicles", timeout=5).json()
zones = ["IST-001", "IST-002", "IST-003", "IST-004", "IST-005", "IST-006"]
now = datetime.now()
payload = {"zones": [], "horizons": [2, 6, 24]}
for i, z in enumerate(zones):
    avail = sum(1 for v in vehicles if v["currentZone"] == z and v["status"] == "AVAILABLE")
    payload["zones"].append({
        "zone_code": z, "zone_encoded": i, "trip_count": 10,
        "rolling_7d_avg_trips": 10, "demand_momentum": 1.0, "revenue_efficiency": 4.0,
        "hour_sin": math.sin(2 * math.pi * now.hour / 24),
        "hour_cos": math.cos(2 * math.pi * now.hour / 24),
        "dow_sin": math.sin(2 * math.pi * now.weekday() / 7),
        "dow_cos": math.cos(2 * math.pi * now.weekday() / 7),
        "is_peak_hour": 1 if now.hour in (7, 8, 9, 17, 18, 19, 20) else 0,
        "is_weekend": 1 if now.weekday() >= 5 else 0,
        "available_vehicles": avail or 1,
    })

preds = requests.post("http://127.0.0.1:8000/predict/batch", json=payload, timeout=15).json()
print(f"\n  Predictions:     {len(preds['predictions'])} zone-horizon scores")

engine = {
    "vehicles": [{
        "id": v["id"], "plate": v["plate"], "status": v["status"].lower(),
        "currentZone": v["currentZone"], "lat": 41.0, "lng": 29.0,
        "batteryPct": v["batteryPct"],
    } for v in vehicles],
    "predictions": [{
        "zoneCode": p["zone_code"], "horizonHours": p["horizon_hours"],
        "demandScore": p["demand_score"], "confidence": p["confidence"],
    } for p in preds["predictions"]],
}
recs = requests.post("http://127.0.0.1:8082/api/v1/decisions/relocations", json=engine, timeout=10).json()
print(f"  Relocations:     {len(recs)} recommendations")
print("\nOpen dashboard: http://localhost:5173")

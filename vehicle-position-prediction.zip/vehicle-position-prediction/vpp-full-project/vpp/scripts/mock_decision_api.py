"""
Lightweight decision engine API (no Spring Boot required).
Mirrors the Java contract on port 8082.
"""

from typing import Optional
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="VPP Decision Engine (Demo)")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

RELOCATION_THRESHOLD = 1.5


class VehiclePosition(BaseModel):
    id: Optional[str] = None
    plate: Optional[str] = None
    status: str = "available"
    currentZone: str
    lat: float = 41.0
    lng: float = 29.0
    batteryPct: int = 80


class ZonePrediction(BaseModel):
    zoneCode: str
    horizonHours: int
    demandScore: float
    confidence: float


class DecisionRequest(BaseModel):
    vehicles: list[VehiclePosition]
    predictions: list[ZonePrediction]


class RelocationRecommendation(BaseModel):
    fromZone: str
    toZone: str
    vehicleCount: int
    horizonHours: int
    demandScore: float
    confidence: float
    urgency: str
    reason: str


def supply_demand_ratio(pred: ZonePrediction, supply: dict[str, int]) -> float:
    vehicles = supply.get(pred.zoneCode, 0)
    if vehicles == 0:
        return pred.demandScore * 10
    return pred.demandScore / vehicles


def compute_vehicles_to_move(hot: ZonePrediction, cold: ZonePrediction, supply: dict[str, int]) -> int:
    cold_supply = supply.get(cold.zoneCode, 0)
    return max(1, min(cold_supply // 2, 3))


@app.post("/api/v1/decisions/relocations", response_model=list[RelocationRecommendation])
def get_relocations(request: DecisionRequest):
    by_horizon: dict[int, list[ZonePrediction]] = {}
    for p in request.predictions:
        by_horizon.setdefault(p.horizonHours, []).append(p)

    supply: dict[str, int] = {}
    for v in request.vehicles:
        if v.status.lower() == "available":
            supply[v.currentZone] = supply.get(v.currentZone, 0) + 1

    recommendations: list[RelocationRecommendation] = []

    for horizon, preds in by_horizon.items():
        ranked = sorted(preds, key=lambda p: -supply_demand_ratio(p, supply))
        if len(ranked) < 2:
            continue

        hot, cold = ranked[0], ranked[-1]
        hot_ratio = supply_demand_ratio(hot, supply)
        cold_ratio = supply_demand_ratio(cold, supply)

        if hot_ratio - cold_ratio > RELOCATION_THRESHOLD:
            n = compute_vehicles_to_move(hot, cold, supply)
            if n > 0:
                urgency = "HIGH" if horizon <= 2 else ("MEDIUM" if horizon <= 6 else "LOW")
                recommendations.append(RelocationRecommendation(
                    fromZone=cold.zoneCode,
                    toZone=hot.zoneCode,
                    vehicleCount=n,
                    horizonHours=horizon,
                    demandScore=hot.demandScore,
                    confidence=hot.confidence,
                    urgency=urgency,
                    reason=(
                        f"Zone {hot.zoneCode} has {hot_ratio:.1f}x demand vs supply; "
                        f"Zone {cold.zoneCode} is oversupplied"
                    ),
                ))

    return recommendations


@app.get("/api/v1/decisions/health")
def health():
    return "Decision engine running"


@app.get("/actuator/health")
def actuator_health():
    return {"status": "UP"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8082)

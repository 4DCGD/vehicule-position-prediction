"""
Lightweight booking + vehicle API (no PostgreSQL required).
Mirrors the Spring Boot contract on port 8081.
"""

from datetime import datetime, timezone, timedelta
from uuid import uuid4
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="VPP Booking API (Demo)")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ZONES = ["IST-001", "IST-002", "IST-003", "IST-004", "IST-005", "IST-006"]

VEHICLES = [
    {"id": str(uuid4()), "plate": "34 VPP 01", "model": "Tesla Model 3",   "status": "AVAILABLE", "currentZone": "IST-001", "batteryPct": 87},
    {"id": str(uuid4()), "plate": "34 VPP 02", "model": "Tesla Model 3",   "status": "AVAILABLE", "currentZone": "IST-001", "batteryPct": 72},
    {"id": str(uuid4()), "plate": "34 VPP 03", "model": "Renault Zoe",     "status": "AVAILABLE", "currentZone": "IST-002", "batteryPct": 91},
    {"id": str(uuid4()), "plate": "34 VPP 04", "model": "Renault Zoe",     "status": "BOOKED",    "currentZone": "IST-002", "batteryPct": 45},
    {"id": str(uuid4()), "plate": "34 VPP 05", "model": "Nissan Leaf",     "status": "AVAILABLE", "currentZone": "IST-003", "batteryPct": 68},
    {"id": str(uuid4()), "plate": "34 VPP 06", "model": "Nissan Leaf",     "status": "AVAILABLE", "currentZone": "IST-003", "batteryPct": 55},
    {"id": str(uuid4()), "plate": "34 VPP 07", "model": "Tesla Model Y",   "status": "AVAILABLE", "currentZone": "IST-004", "batteryPct": 93},
    {"id": str(uuid4()), "plate": "34 VPP 08", "model": "Tesla Model Y",   "status": "RELOCATING","currentZone": "IST-004", "batteryPct": 78},
    {"id": str(uuid4()), "plate": "34 VPP 09", "model": "Hyundai Kona EV", "status": "AVAILABLE", "currentZone": "IST-005", "batteryPct": 82},
    {"id": str(uuid4()), "plate": "34 VPP 10", "model": "Hyundai Kona EV", "status": "AVAILABLE", "currentZone": "IST-006", "batteryPct": 61},
]

BOOKINGS: list[dict] = []


class BookingIn(BaseModel):
    vehicleId: Optional[str] = None
    pickupZone: str
    dropoffZone: Optional[str] = None
    pickupTime: Optional[str] = None


@app.get("/api/v1/vehicles")
def list_vehicles():
    return VEHICLES


@app.get("/api/v1/vehicles/available")
def list_available():
    return [v for v in VEHICLES if v["status"] == "AVAILABLE"]


@app.get("/api/v1/vehicles/zone/{zone}")
def vehicles_by_zone(zone: str):
    return [v for v in VEHICLES if v["currentZone"] == zone]


@app.get("/api/v1/bookings")
def list_bookings(page: int = 0, size: int = 20):
    start = page * size
    return BOOKINGS[start:start + size]


@app.get("/api/v1/bookings/zone/{zone}")
def bookings_by_zone(zone: str):
    return [b for b in BOOKINGS if b["pickupZone"] == zone]


@app.post("/api/v1/bookings/seed")
def seed_bookings():
    import random
    rng = random.Random(42)
    count = 50
    for _ in range(count):
        start = datetime.now(tz=timezone.utc) - timedelta(days=rng.randint(1, 30))
        BOOKINGS.append({
            "id": str(uuid4()),
            "vehicleId": rng.choice(VEHICLES)["id"],
            "pickupZone": rng.choice(ZONES),
            "dropoffZone": rng.choice(ZONES),
            "pickupTime": start.isoformat(),
            "dropoffTime": (start + timedelta(minutes=rng.randint(15, 75))).isoformat(),
            "revenueUsd": round(5 + rng.random() * 45, 2),
            "distanceKm": round(1 + rng.random() * 20, 3),
            "status": "COMPLETED",
        })
    return f"Seeded {count} bookings"


@app.get("/actuator/health")
def health():
    return {"status": "UP"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8081)

"""
Fetch live predictions from the serving API and persist to zone_demand_predictions.
Used by Sprint 5 evaluation pipeline.

Usage:
    python scripts/store_predictions.py
"""

import os
import logging
from datetime import datetime, timedelta, timezone

import psycopg2
import requests

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

PG_DSN = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")
MODEL_API = os.getenv("MODEL_API", "http://localhost:8000")
BOOKING_API = os.getenv("BOOKING_API", "http://localhost:8081")

ZONES = ["IST-001", "IST-002", "IST-003", "IST-004", "IST-005", "IST-006"]


def build_payload(vehicles):
    now = datetime.now(tz=timezone.utc)
    hour, dow = now.hour, now.weekday()
    import math
    return {
        "zones": [
            {
                "zone_code": z,
                "zone_encoded": i,
                "trip_count": 10,
                "rolling_7d_avg_trips": 10,
                "demand_momentum": 1.0,
                "revenue_efficiency": 4.0,
                "hour_sin": math.sin(2 * math.pi * hour / 24),
                "hour_cos": math.cos(2 * math.pi * hour / 24),
                "dow_sin": math.sin(2 * math.pi * dow / 7),
                "dow_cos": math.cos(2 * math.pi * dow / 7),
                "is_peak_hour": 1 if hour in (7, 8, 9, 17, 18, 19, 20) else 0,
                "is_weekend": 1 if dow >= 5 else 0,
                "available_vehicles": sum(
                    1 for v in vehicles
                    if v.get("currentZone") == z and v.get("status") == "AVAILABLE"
                ) or 1,
            }
            for i, z in enumerate(ZONES)
        ],
        "horizons": [2, 6, 24],
    }


def run():
    vehicles = requests.get(f"{BOOKING_API}/api/v1/vehicles", timeout=10).json()
    payload = build_payload(vehicles)
    result = requests.post(f"{MODEL_API}/predict/batch", json=payload, timeout=30).json()

    now = datetime.now(tz=timezone.utc)
    rows = []
    for p in result["predictions"]:
        forecast_for = now + timedelta(hours=p["horizon_hours"])
        rows.append((
            p["zone_code"],
            p["horizon_hours"],
            now,
            forecast_for,
            p["demand_score"],
            p["confidence"],
            result.get("model_versions", {}).get(f"{p['horizon_hours']}h", "local"),
        ))

    conn = psycopg2.connect(PG_DSN)
    with conn.cursor() as cur:
        cur.executemany("""
            INSERT INTO zone_demand_predictions
                (zone_code, horizon_hours, predicted_at, forecast_for,
                 demand_score, confidence, model_version)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, rows)
    conn.commit()
    conn.close()
    log.info("Stored %d predictions", len(rows))


if __name__ == "__main__":
    run()

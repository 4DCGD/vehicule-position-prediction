"""
Bootstrap script — seeds historical bookings and builds the demand mart.
Run after docker-compose up and before training.

Usage:
    python scripts/bootstrap_data.py
"""

import os
import random
import logging
from datetime import datetime, timedelta, timezone

import psycopg2
import psycopg2.extras

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

PG_DSN = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")
ZONES = ["IST-001", "IST-002", "IST-003", "IST-004", "IST-005", "IST-006"]
DAYS_OF_HISTORY = int(os.getenv("HISTORY_DAYS", "30"))


def get_conn():
    return psycopg2.connect(PG_DSN)


def seed_historical_bookings(conn, per_day: int = 40):
    """Generate realistic hourly booking patterns for the past N days."""
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM bookings")
        existing = cur.fetchone()[0]
    if existing >= 200:
        log.info("Bookings already seeded (%d rows), skipping", existing)
        return existing

    with conn.cursor() as cur:
        cur.execute("SELECT id FROM vehicles")
        vehicle_ids = [row[0] for row in cur.fetchall()]

    if not vehicle_ids:
        log.error("No vehicles found — run docker-compose first")
        return 0

    rows = []
    now = datetime.now(tz=timezone.utc)
    rng = random.Random(42)

    for day_offset in range(DAYS_OF_HISTORY, 0, -1):
        day = now - timedelta(days=day_offset)
        dow = day.weekday()
        is_weekend = dow >= 5

        for hour in range(24):
            # Peak hours get more trips
            base = per_day // 24
            if hour in (7, 8, 9, 17, 18, 19, 20):
                n_trips = base + rng.randint(2, 6)
            elif is_weekend and hour in (11, 12, 13, 14, 15, 16):
                n_trips = base + rng.randint(1, 4)
            else:
                n_trips = max(0, base + rng.randint(-1, 2))

            for _ in range(n_trips):
                pickup = rng.choice(ZONES)
                dropoff = rng.choice([z for z in ZONES if z != pickup] or ZONES)
                start = day.replace(hour=hour, minute=rng.randint(0, 59), second=0,
                                    microsecond=0, tzinfo=timezone.utc)
                duration = rng.randint(10, 75)
                rows.append((
                    rng.choice(vehicle_ids),
                    pickup,
                    dropoff,
                    start,
                    start + timedelta(minutes=duration),
                    round(5 + rng.random() * 45, 2),
                    round(1 + rng.random() * 20, 3),
                    "COMPLETED",  # matches JPA BookingStatus.COMPLETED
                ))

    insert_sql = """
        INSERT INTO bookings
            (vehicle_id, pickup_zone, dropoff_zone, pickup_time, dropoff_time,
             revenue_usd, distance_km, status)
        VALUES %s
    """
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, insert_sql, rows)
    conn.commit()
    log.info("Seeded %d historical bookings", len(rows))
    return len(rows)


def build_mart(conn):
    """Create mart_zone_hourly_demand table (same logic as dbt model)."""
    sql = """
    DROP TABLE IF EXISTS marts.mart_zone_hourly_demand;

    CREATE TABLE marts.mart_zone_hourly_demand AS
    WITH bookings AS (
        SELECT
            pickup_zone,
            pickup_time,
            dropoff_time,
            revenue_usd,
            distance_km,
            vehicle_id,
            status,
            EXTRACT(EPOCH FROM (dropoff_time - pickup_time)) / 60.0 AS duration_minutes,
            DATE_TRUNC('hour', pickup_time) AS pickup_hour,
            EXTRACT(DOW FROM pickup_time) AS day_of_week,
            EXTRACT(HOUR FROM pickup_time) AS hour_of_day
        FROM bookings
        WHERE status = 'COMPLETED'
          AND dropoff_time > pickup_time
          AND revenue_usd > 0
    ),
    zone_hour_agg AS (
        SELECT
            pickup_zone AS zone_code,
            pickup_hour AS hour_bucket,
            day_of_week::int,
            hour_of_day::int,
            COUNT(*) AS trip_count,
            COUNT(DISTINCT vehicle_id) AS unique_vehicles,
            SUM(revenue_usd) AS total_revenue,
            AVG(revenue_usd) AS avg_revenue,
            AVG(duration_minutes) AS avg_duration_min,
            AVG(distance_km) AS avg_distance_km
        FROM bookings
        GROUP BY pickup_zone, pickup_hour, day_of_week, hour_of_day
    )
    SELECT
        *,
        AVG(trip_count) OVER (
            PARTITION BY zone_code, hour_of_day, day_of_week
            ORDER BY hour_bucket
            ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
        ) AS rolling_7d_avg_trips,
        AVG(total_revenue) OVER (
            PARTITION BY zone_code, hour_of_day, day_of_week
            ORDER BY hour_bucket
            ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
        ) AS rolling_7d_avg_revenue
    FROM zone_hour_agg
    ORDER BY zone_code, hour_bucket;
    """
    with conn.cursor() as cur:
        cur.execute(sql)
        cur.execute("SELECT COUNT(*) FROM marts.mart_zone_hourly_demand")
        count = cur.fetchone()[0]
    conn.commit()
    log.info("Built mart_zone_hourly_demand with %d rows", count)
    return count


def run():
    conn = get_conn()
    try:
        seed_historical_bookings(conn)
        build_mart(conn)
        log.info("Bootstrap complete")
    finally:
        conn.close()


if __name__ == "__main__":
    run()

"""
Sprint 5 – A/B Testing & Model Evaluation
Compares model predictions against actual outcomes to validate accuracy
and trigger retraining when drift is detected.
"""

import os
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Literal

import numpy as np
import pandas as pd
import psycopg2
import mlflow
from scipy import stats

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

PG_DSN    = os.getenv("PG_DSN",    "postgresql://vpp:vpp_secret@localhost:5432/vpp")
MLFLOW_URI = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")

MAE_THRESHOLD  = float(os.getenv("MAE_THRESHOLD",  "3.0"))   # trip count MAE
DRIFT_Z_SCORE  = float(os.getenv("DRIFT_Z_SCORE",  "2.5"))


@dataclass
class EvaluationResult:
    horizon_hours: int
    n_samples:     int
    mae:           float
    rmse:          float
    r2:            float
    bias:          float
    drift_detected: bool
    p_value:       float


# ── Load data ─────────────────────────────────────────────────
def load_predictions_vs_actuals(conn, horizon: int, days: int = 7) -> pd.DataFrame:
    """
    Join predictions against actual demand observed after forecast_for.
    """
    since = datetime.now(tz=timezone.utc) - timedelta(days=days)
    query = f"""
        WITH actuals AS (
            SELECT
                pickup_zone                     AS zone_code,
                date_trunc('hour', pickup_time) AS hour_bucket,
                COUNT(*)                        AS actual_trips
            FROM bookings
            WHERE pickup_time >= %s AND status = 'COMPLETED'
            GROUP BY pickup_zone, hour_bucket
        )
        SELECT
            p.zone_code,
            p.forecast_for,
            p.demand_score                      AS predicted,
            p.confidence,
            p.model_version,
            COALESCE(a.actual_trips, 0)         AS actual
        FROM zone_demand_predictions p
        LEFT JOIN actuals a
          ON a.zone_code  = p.zone_code
         AND a.hour_bucket = p.forecast_for
        WHERE p.horizon_hours = %s
          AND p.predicted_at  >= %s
        ORDER BY p.forecast_for
    """
    return pd.read_sql(query, conn, params=(since, horizon, since))


# ── Metrics ───────────────────────────────────────────────────
def compute_metrics(df: pd.DataFrame, horizon: int) -> EvaluationResult:
    errors = df["predicted"] - df["actual"]

    mae  = float(np.mean(np.abs(errors)))
    rmse = float(np.sqrt(np.mean(errors ** 2)))
    ss_res = np.sum(errors ** 2)
    ss_tot = np.sum((df["actual"] - df["actual"].mean()) ** 2)
    r2   = float(1 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    bias = float(np.mean(errors))

    # Drift: one-sample t-test on errors (H0: mean=0)
    t_stat, p_value = stats.ttest_1samp(errors, 0)
    drift = bool(abs(t_stat) > DRIFT_Z_SCORE)

    return EvaluationResult(
        horizon_hours=horizon,
        n_samples=len(df),
        mae=mae,
        rmse=rmse,
        r2=r2,
        bias=bias,
        drift_detected=drift,
        p_value=float(p_value),
    )


# ── Log to MLflow ─────────────────────────────────────────────
def log_evaluation(result: EvaluationResult, run_name: str):
    mlflow.set_tracking_uri(MLFLOW_URI)
    mlflow.set_experiment("vpp-model-evaluation")
    with mlflow.start_run(run_name=run_name):
        mlflow.log_metrics({
            "eval_mae":           result.mae,
            "eval_rmse":          result.rmse,
            "eval_r2":            result.r2,
            "eval_bias":          result.bias,
            "eval_p_value":       result.p_value,
            "eval_n_samples":     result.n_samples,
            "drift_detected":     int(result.drift_detected),
        })
        mlflow.log_param("horizon_hours", result.horizon_hours)


# ── Per-zone breakdown ────────────────────────────────────────
def zone_breakdown(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("zone_code")
        .apply(lambda g: pd.Series({
            "mae":    np.mean(np.abs(g["predicted"] - g["actual"])),
            "bias":   np.mean(g["predicted"] - g["actual"]),
            "n":      len(g),
        }))
        .reset_index()
        .sort_values("mae", ascending=False)
    )


# ── Main ──────────────────────────────────────────────────────
def run():
    conn = psycopg2.connect(PG_DSN)
    log.info("Running model evaluation for all horizons…")

    alerts = []
    for horizon in [2, 6, 24]:
        df = load_predictions_vs_actuals(conn, horizon)
        if len(df) < 10:
            log.warning("Not enough data for %dh horizon (%d rows)", horizon, len(df))
            continue

        result = compute_metrics(df, horizon)
        log_evaluation(result, f"eval_{horizon}h_{datetime.now().strftime('%Y%m%d_%H%M')}")

        log.info(
            "[%2dh] n=%d  MAE=%.3f  RMSE=%.3f  R2=%.3f  bias=%.3f  drift=%s  p=%.4f",
            horizon, result.n_samples, result.mae, result.rmse,
            result.r2, result.bias,
            "⚠ YES" if result.drift_detected else "no", result.p_value,
        )

        if result.mae > MAE_THRESHOLD:
            alerts.append(f"⚠  {horizon}h model MAE={result.mae:.2f} exceeds threshold {MAE_THRESHOLD}")
        if result.drift_detected:
            alerts.append(f"🔴 {horizon}h model DRIFT detected (p={result.p_value:.4f}) — retrain recommended")

        # Per-zone breakdown
        breakdown = zone_breakdown(df)
        log.info("  Worst zones:\n%s", breakdown.head(3).to_string(index=False))

    conn.close()

    if alerts:
        log.warning("\n── ALERTS ──")
        for a in alerts:
            log.warning("  %s", a)
    else:
        log.info("✓ All models within acceptable thresholds")


if __name__ == "__main__":
    run()

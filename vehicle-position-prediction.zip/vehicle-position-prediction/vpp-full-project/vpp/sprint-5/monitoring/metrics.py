"""
Sprint 5 – Prometheus Metrics Instrumentation
Add these metrics to the FastAPI serving API for real-time monitoring.
"""

from prometheus_client import Counter, Histogram, Gauge, start_http_server
import time
import functools

# ── Metrics ───────────────────────────────────────────────────
prediction_requests = Counter(
    "vpp_prediction_requests_total",
    "Total prediction requests",
    ["horizon", "status"],
)

prediction_latency = Histogram(
    "vpp_prediction_latency_seconds",
    "Prediction request latency",
    ["horizon"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0],
)

prediction_score = Histogram(
    "vpp_prediction_demand_score",
    "Distribution of predicted demand scores",
    ["horizon", "zone"],
    buckets=[0, 2, 5, 10, 15, 20, 30, 50],
)

model_confidence = Gauge(
    "vpp_model_confidence",
    "Average model confidence",
    ["horizon"],
)

active_relocations = Gauge(
    "vpp_active_relocations",
    "Number of active relocation recommendations",
)

kafka_consumer_lag = Gauge(
    "vpp_kafka_consumer_lag",
    "Kafka consumer lag (GPS events)",
    ["partition"],
)


# ── Decorator for FastAPI endpoints ───────────────────────────
def track_prediction(horizon: int):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            start = time.perf_counter()
            try:
                result = await func(*args, **kwargs)
                prediction_requests.labels(horizon=str(horizon), status="success").inc()
                return result
            except Exception as e:
                prediction_requests.labels(horizon=str(horizon), status="error").inc()
                raise
            finally:
                elapsed = time.perf_counter() - start
                prediction_latency.labels(horizon=str(horizon)).observe(elapsed)
        return wrapper
    return decorator

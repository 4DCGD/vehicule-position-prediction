import { useState, useEffect, useCallback } from "react";

const MODEL_API  = import.meta.env.VITE_MODEL_API  || "http://localhost:8000";
const ENGINE_API = import.meta.env.VITE_ENGINE_API || "http://localhost:8082";
const BOOKING_API = import.meta.env.VITE_BOOKING_API || "http://localhost:8081";

// ── Generic fetcher ────────────────────────────────────────────
async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
  return res.json();
}

// ── Predictions hook ───────────────────────────────────────────
export function usePredictions(zones, horizons = [2, 6, 24]) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const fetch = useCallback(async () => {
    if (!zones?.length) return;
    setLoading(true);
    setError(null);
    try {
      const payload = {
        zones: zones.map((z, i) => ({
          zone_code:            z.code,
          zone_encoded:         i,
          trip_count:           z.tripCount      ?? 10,
          rolling_7d_avg_trips: z.rollingAvg     ?? 10,
          demand_momentum:      z.momentum        ?? 1.0,
          revenue_efficiency:   z.revEfficiency  ?? 4.0,
          hour_sin:  Math.sin(2 * Math.PI * new Date().getHours() / 24),
          hour_cos:  Math.cos(2 * Math.PI * new Date().getHours() / 24),
          dow_sin:   Math.sin(2 * Math.PI * new Date().getDay() / 7),
          dow_cos:   Math.cos(2 * Math.PI * new Date().getDay() / 7),
          is_peak_hour:       [7,8,9,17,18,19,20].includes(new Date().getHours()) ? 1 : 0,
          is_weekend:         new Date().getDay() >= 5 ? 1 : 0,
          available_vehicles: z.availableVehicles ?? 3,
        })),
        horizons,
      };
      const result = await apiFetch(`${MODEL_API}/predict/batch`, {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setData(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [zones, horizons]);

  useEffect(() => {
    fetch();
    const id = setInterval(fetch, 60_000);
    return () => clearInterval(id);
  }, [fetch]);

  return { data, loading, error, refetch: fetch };
}

// ── Recommendations hook ───────────────────────────────────────
export function useRecommendations(vehicles, predictions) {
  const [data,    setData]    = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!vehicles?.length || !predictions?.length) return;

    setLoading(true);
    apiFetch(`${ENGINE_API}/api/v1/decisions/relocations`, {
      method: "POST",
      body: JSON.stringify({ vehicles, predictions }),
    })
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [vehicles, predictions]);

  return { data, loading };
}

// ── Bookings hook ──────────────────────────────────────────────
export function useBookings(zone) {
  const [data,    setData]    = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!zone) return;
    setLoading(true);
    apiFetch(`${BOOKING_API}/api/v1/bookings/zone/${zone}`)
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [zone]);

  return { data, loading };
}

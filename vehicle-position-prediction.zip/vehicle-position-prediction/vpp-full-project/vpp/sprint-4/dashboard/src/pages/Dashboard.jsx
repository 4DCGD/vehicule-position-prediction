import { useState, useEffect, useCallback } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Legend,
} from "recharts";

const BOOKING_API = import.meta.env.VITE_BOOKING_API || "http://localhost:8081";
const MODEL_API   = import.meta.env.VITE_MODEL_API   || "http://localhost:8000";
const ENGINE_API  = import.meta.env.VITE_ENGINE_API  || "http://localhost:8082";

const ZONES = [
  { code: "IST-001", name: "Beyoglu" },
  { code: "IST-002", name: "Sisli" },
  { code: "IST-003", name: "Kadikoy" },
  { code: "IST-004", name: "Besiktas" },
  { code: "IST-005", name: "Uskudar" },
  { code: "IST-006", name: "Fatih" },
];

const urgencyColor = { HIGH: "#ef4444", MEDIUM: "#f59e0b", LOW: "#22c55e" };
const demandColor = (score) => {
  if (score > 18) return "#ef4444";
  if (score > 10) return "#f59e0b";
  return "#22c55e";
};

async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div style={{
      background: "#111827", border: `1px solid ${accent}33`,
      borderRadius: 12, padding: "16px 20px",
      display: "flex", flexDirection: "column", gap: 4,
    }}>
      <span style={{ color: "#6b7280", fontSize: 12, letterSpacing: "0.05em", textTransform: "uppercase" }}>{label}</span>
      <span style={{ color: accent, fontSize: 28, fontWeight: 700, fontFamily: "monospace" }}>{value}</span>
      {sub && <span style={{ color: "#9ca3af", fontSize: 12 }}>{sub}</span>}
    </div>
  );
}

function DemandBar({ zone }) {
  return (
    <div style={{
      background: "#111827", borderRadius: 10,
      padding: "12px 16px", border: "1px solid #1f2937",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ color: "#f9fafb", fontWeight: 600 }}>{zone.zone_name}</span>
        <span style={{
          background: "#1f2937", color: "#9ca3af",
          padding: "2px 8px", borderRadius: 20, fontSize: 12,
        }}>
          {zone.available_vehicles} available
        </span>
      </div>
      {[["2h", zone.demand_2h], ["6h", zone.demand_6h], ["24h", zone.demand_24h]].map(([label, val]) => (
        <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
          <span style={{ color: "#6b7280", fontSize: 11, width: 24 }}>{label}</span>
          <div style={{ flex: 1, background: "#1f2937", borderRadius: 4, height: 8 }}>
            <div style={{
              width: `${Math.min(100, val / 35 * 100)}%`,
              height: "100%", borderRadius: 4,
              background: demandColor(val),
              transition: "width 0.6s ease",
            }} />
          </div>
          <span style={{ color: demandColor(val), fontSize: 12, fontWeight: 600, width: 32 }}>{val}</span>
        </div>
      ))}
    </div>
  );
}

function RecommendationCard({ rec, onAccept }) {
  return (
    <div style={{
      background: "#111827",
      border: `1px solid ${urgencyColor[rec.urgency]}44`,
      borderLeft: `3px solid ${urgencyColor[rec.urgency]}`,
      borderRadius: 10, padding: "14px 16px",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{
          background: urgencyColor[rec.urgency] + "22",
          color: urgencyColor[rec.urgency],
          padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 700,
        }}>{rec.urgency}</span>
        <span style={{ color: "#6b7280", fontSize: 12 }}>
          Move {rec.vehicleCount ?? rec.count} vehicle{(rec.vehicleCount ?? rec.count) > 1 ? "s" : ""}
        </span>
      </div>
      <div style={{ color: "#f9fafb", fontWeight: 600, marginBottom: 4 }}>
        {rec.fromZone ?? rec.from} → {rec.toZone ?? rec.to}
      </div>
      <p style={{ color: "#9ca3af", fontSize: 12, margin: "0 0 10px" }}>{rec.reason}</p>
      <button
        onClick={() => onAccept(rec)}
        style={{
          background: urgencyColor[rec.urgency], color: "#fff",
          border: "none", borderRadius: 6, padding: "6px 14px",
          cursor: "pointer", fontSize: 12, fontWeight: 600,
        }}
      >
        Dispatch
      </button>
    </div>
  );
}

function buildZonePayload(zones, vehicles) {
  const now = new Date();
  const hour = now.getHours();
  const dow = now.getDay();
  return zones.map((z, i) => {
    const zoneVehicles = vehicles.filter(v => v.currentZone === z.code);
    return {
      zone_code: z.code,
      zone_encoded: i,
      trip_count: 10 + zoneVehicles.length * 2,
      rolling_7d_avg_trips: 10,
      demand_momentum: 1.0,
      revenue_efficiency: 4.0,
      hour_sin: Math.sin(2 * Math.PI * hour / 24),
      hour_cos: Math.cos(2 * Math.PI * hour / 24),
      dow_sin: Math.sin(2 * Math.PI * dow / 7),
      dow_cos: Math.cos(2 * Math.PI * dow / 7),
      is_peak_hour: [7, 8, 9, 17, 18, 19, 20].includes(hour) ? 1 : 0,
      is_weekend: dow >= 5 ? 1 : 0,
      available_vehicles: zoneVehicles.filter(v => v.status === "AVAILABLE").length || 1,
    };
  });
}

function predictionsToZoneData(predictions, zones, vehicles) {
  const byZone = {};
  for (const p of predictions) {
    if (!byZone[p.zone_code]) {
      const z = zones.find(z => z.code === p.zone_code);
      const avail = vehicles.filter(v => v.currentZone === p.zone_code && v.status === "AVAILABLE").length;
      byZone[p.zone_code] = {
        zone_code: p.zone_code,
        zone_name: z?.name ?? p.zone_code,
        demand_2h: 0, demand_6h: 0, demand_24h: 0,
        available_vehicles: avail,
        confidence: p.confidence,
      };
    }
    const key = `demand_${p.horizon_hours}h`;
    byZone[p.zone_code][key] = p.demand_score;
    byZone[p.zone_code].confidence = Math.max(byZone[p.zone_code].confidence, p.confidence);
  }
  return Object.values(byZone);
}

export default function Dashboard() {
  const [predictions, setPredictions] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [selectedHorizon, setSelectedHorizon] = useState("2h");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [dispatched, setDispatched] = useState([]);
  const [apiStatus, setApiStatus] = useState("loading");
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      const vehicles = await apiFetch(`${BOOKING_API}/api/v1/vehicles`);
      const payload = {
        zones: buildZonePayload(ZONES, vehicles),
        horizons: [2, 6, 24],
      };
      const result = await apiFetch(`${MODEL_API}/predict/batch`, {
        method: "POST",
        body: JSON.stringify(payload),
      });

      const preds = predictionsToZoneData(result.predictions, ZONES, vehicles);
      setPredictions(preds);
      setApiStatus("live");

      const enginePayload = {
        vehicles: vehicles.map(v => ({
          id: v.id,
          plate: v.plate,
          status: (v.status || "available").toLowerCase(),
          currentZone: v.currentZone,
          lat: 41.0,
          lng: 29.0,
          batteryPct: v.batteryPct ?? 80,
        })),
        predictions: result.predictions.map(p => ({
          zoneCode: p.zone_code,
          horizonHours: p.horizon_hours,
          demandScore: p.demand_score,
          confidence: p.confidence,
        })),
      };

      const recs = await apiFetch(`${ENGINE_API}/api/v1/decisions/relocations`, {
        method: "POST",
        body: JSON.stringify(enginePayload),
      });
      setRecommendations(recs);
      setLastUpdated(new Date().toLocaleTimeString());
      setError(null);
    } catch (e) {
      setApiStatus("offline");
      setError(e.message);
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 30_000);
    return () => clearInterval(id);
  }, [refresh]);

  const totalAvailable = predictions.reduce((s, p) => s + p.available_vehicles, 0);
  const highDemandZones = predictions.filter(p => p.demand_2h > 12).length;
  const avgConfidence = predictions.length
    ? (predictions.reduce((s, p) => s + p.confidence, 0) / predictions.length * 100).toFixed(0)
    : 0;

  const horizonKey = { "2h": "demand_2h", "6h": "demand_6h", "24h": "demand_24h" }[selectedHorizon];
  const chartData = predictions.map(p => ({
    name: p.zone_name.slice(0, 3),
    demand: p[horizonKey],
    supply: p.available_vehicles,
  }));

  function handleDispatch(rec) {
    setDispatched(d => [...d, rec]);
    setRecommendations(r => r.filter(r2 => r2 !== rec));
  }

  return (
    <div style={{
      minHeight: "100vh", background: "#030712", color: "#f9fafb",
      fontFamily: "'IBM Plex Mono', monospace", padding: "24px",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, letterSpacing: "-0.02em" }}>
            Fleet Position Intelligence
          </h1>
          <p style={{ margin: "4px 0 0", color: "#4b5563", fontSize: 12 }}>
            Istanbul · {apiStatus === "live" ? "Live" : "Connecting..."} · Updated {lastUpdated || "—"}
          </p>
          {error && <p style={{ color: "#f87171", fontSize: 11, margin: "4px 0 0" }}>{error}</p>}
        </div>
        <button onClick={refresh} style={{
          background: "#1f2937", color: "#9ca3af",
          border: "1px solid #374151", borderRadius: 8,
          padding: "8px 16px", cursor: "pointer", fontSize: 12,
        }}>
          Refresh
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12, marginBottom: 24 }}>
        <StatCard label="Zones Monitored" value={predictions.length || ZONES.length} sub="Istanbul grid" accent="#60a5fa" />
        <StatCard label="Available Vehicles" value={totalAvailable} sub="across all zones" accent="#34d399" />
        <StatCard label="High Demand Zones" value={highDemandZones} sub="demand score > 12" accent="#f87171" />
        <StatCard label="Avg Confidence" value={`${avgConfidence}%`} sub="model prediction quality" accent="#a78bfa" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "flex", gap: 8 }}>
            {["2h", "6h", "24h"].map(h => (
              <button key={h} onClick={() => setSelectedHorizon(h)} style={{
                background: selectedHorizon === h ? "#2563eb" : "#111827",
                color: selectedHorizon === h ? "#fff" : "#6b7280",
                border: selectedHorizon === h ? "1px solid #3b82f6" : "1px solid #1f2937",
                borderRadius: 8, padding: "6px 16px",
                cursor: "pointer", fontSize: 13, fontWeight: 600,
              }}>
                {h} horizon
              </button>
            ))}
          </div>

          <div style={{ background: "#0f172a", borderRadius: 12, border: "1px solid #1e293b", padding: "20px" }}>
            <h3 style={{ margin: "0 0 16px", fontSize: 13, color: "#94a3b8", fontWeight: 600 }}>
              DEMAND VS SUPPLY — {selectedHorizon.toUpperCase()} FORECAST
            </h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" tick={{ fill: "#64748b", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#64748b", fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #334155", borderRadius: 8 }} />
                <Legend wrapperStyle={{ color: "#64748b", fontSize: 12 }} />
                <Bar dataKey="demand" name="Demand" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="supply" name="Supply" fill="#22c55e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {predictions.map(zone => (
              <DemandBar key={zone.zone_code} zone={zone} />
            ))}
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <h3 style={{ margin: 0, fontSize: 13, color: "#94a3b8", fontWeight: 600 }}>
            RELOCATION RECOMMENDATIONS
          </h3>
          {recommendations.length === 0 ? (
            <div style={{
              background: "#111827", borderRadius: 10, padding: 20,
              color: "#4b5563", fontSize: 13, textAlign: "center",
            }}>
              Fleet distribution optimal
            </div>
          ) : (
            recommendations.map((rec, i) => (
              <RecommendationCard key={i} rec={rec} onAccept={handleDispatch} />
            ))
          )}

          {dispatched.length > 0 && (
            <>
              <h3 style={{ margin: "8px 0 0", fontSize: 13, color: "#94a3b8", fontWeight: 600 }}>DISPATCHED</h3>
              {dispatched.map((rec, i) => (
                <div key={i} style={{
                  background: "#052e16", borderRadius: 10,
                  border: "1px solid #166534", padding: "10px 14px",
                  color: "#86efac", fontSize: 12,
                }}>
                  {rec.vehicleCount ?? rec.count}× {rec.fromZone ?? rec.from} → {rec.toZone ?? rec.to}
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

package com.vpp.decision.model;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ZonePrediction {
    private String zoneCode;
    private int    horizonHours;
    private double demandScore;
    private double confidence;
}

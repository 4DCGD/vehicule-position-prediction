package com.vpp.decision.model;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class RelocationRecommendation {
    private String fromZone;
    private String toZone;
    private int    vehicleCount;
    private int    horizonHours;
    private double demandScore;
    private double confidence;
    private String urgency;
    private String reason;
}

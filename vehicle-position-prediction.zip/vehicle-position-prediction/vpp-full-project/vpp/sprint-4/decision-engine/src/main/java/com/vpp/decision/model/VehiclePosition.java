package com.vpp.decision.model;

import lombok.*;
import java.util.UUID;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class VehiclePosition {
    private UUID   id;
    private String plate;
    private String status;
    private String currentZone;
    private double lat;
    private double lng;
    private int    batteryPct;
}

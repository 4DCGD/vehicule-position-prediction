package com.vpp.decision.model;

import lombok.*;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor
public class DecisionRequest {
    private List<VehiclePosition> vehicles;
    private List<ZonePrediction>  predictions;
}

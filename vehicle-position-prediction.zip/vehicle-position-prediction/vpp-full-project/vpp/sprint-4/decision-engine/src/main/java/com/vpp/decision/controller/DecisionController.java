package com.vpp.decision.controller;

import com.vpp.decision.model.*;
import com.vpp.decision.service.DecisionEngineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/decisions")
@RequiredArgsConstructor
public class DecisionController {

    private final DecisionEngineService engine;

    /**
     * POST /api/v1/decisions/relocations
     * Body: { vehicles: [...], predictions: [...] }
     * Returns: list of recommended relocations
     */
    @PostMapping("/relocations")
    public ResponseEntity<List<RelocationRecommendation>> getRelocations(
            @RequestBody DecisionRequest request
    ) {
        List<RelocationRecommendation> recommendations =
            engine.computeRelocations(request.getVehicles(), request.getPredictions());
        return ResponseEntity.ok(recommendations);
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Decision engine running");
    }
}

package com.vpp.decision.service;

import com.vpp.decision.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class DecisionEngineService {

    private final WebClient modelApiClient;

    @Value("${vpp.model.api.url:http://localhost:8000}")
    private String modelApiUrl;

    // Minimum demand score delta to trigger a relocation recommendation
    private static final double RELOCATION_THRESHOLD = 1.5;

    /**
     * Main entrypoint: given current vehicle positions and model predictions,
     * compute and return relocation recommendations.
     */
    public List<RelocationRecommendation> computeRelocations(
            List<VehiclePosition> vehicles,
            List<ZonePrediction>  predictions
    ) {
        // Group predictions by horizon
        Map<Integer, List<ZonePrediction>> byHorizon = predictions.stream()
                .collect(Collectors.groupingBy(ZonePrediction::getHorizonHours));

        // Count available vehicles per zone
        Map<String, Long> vehiclesPerZone = vehicles.stream()
                .filter(v -> "available".equals(v.getStatus()))
                .collect(Collectors.groupingBy(VehiclePosition::getCurrentZone, Collectors.counting()));

        // Score zones by demand-to-supply ratio for each horizon
        List<RelocationRecommendation> recommendations = new ArrayList<>();

        for (var entry : byHorizon.entrySet()) {
            int horizon = entry.getKey();
            List<ZonePrediction> preds = entry.getValue();

            // Rank zones by demand per available vehicle
            List<ZonePrediction> ranked = preds.stream()
                    .sorted(Comparator.comparingDouble(p -> -supplyDemandRatio(p, vehiclesPerZone)))
                    .collect(Collectors.toList());

            if (ranked.size() < 2) continue;

            ZonePrediction hotZone  = ranked.get(0);
            ZonePrediction coldZone = ranked.get(ranked.size() - 1);

            double hotRatio  = supplyDemandRatio(hotZone,  vehiclesPerZone);
            double coldRatio = supplyDemandRatio(coldZone, vehiclesPerZone);

            if (hotRatio - coldRatio > RELOCATION_THRESHOLD) {
                int vehiclesToMove = computeVehiclesToMove(hotZone, coldZone, vehiclesPerZone);
                if (vehiclesToMove > 0) {
                    recommendations.add(RelocationRecommendation.builder()
                            .fromZone(coldZone.getZoneCode())
                            .toZone(hotZone.getZoneCode())
                            .vehicleCount(vehiclesToMove)
                            .horizonHours(horizon)
                            .demandScore(hotZone.getDemandScore())
                            .confidence(hotZone.getConfidence())
                            .urgency(horizon <= 2 ? "HIGH" : horizon <= 6 ? "MEDIUM" : "LOW")
                            .reason(String.format(
                                "Zone %s has %.1fx demand vs supply; Zone %s is oversupplied",
                                hotZone.getZoneCode(), hotRatio, coldZone.getZoneCode()
                            ))
                            .build());
                }
            }
        }

        log.info("Generated {} relocation recommendations", recommendations.size());
        return recommendations;
    }

    private double supplyDemandRatio(ZonePrediction pred, Map<String, Long> supply) {
        long vehicles = supply.getOrDefault(pred.getZoneCode(), 0L);
        if (vehicles == 0) return pred.getDemandScore() * 10; // infinite demand pressure
        return pred.getDemandScore() / vehicles;
    }

    private int computeVehiclesToMove(
            ZonePrediction hot, ZonePrediction cold,
            Map<String, Long> supply
    ) {
        long coldSupply = supply.getOrDefault(cold.getZoneCode(), 0L);
        // Move at most half of cold zone's vehicles, minimum 1
        return (int) Math.max(1, Math.min(coldSupply / 2, 3));
    }
}

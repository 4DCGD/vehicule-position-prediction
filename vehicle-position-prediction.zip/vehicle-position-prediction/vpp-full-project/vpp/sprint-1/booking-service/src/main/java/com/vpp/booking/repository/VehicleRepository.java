package com.vpp.booking.repository;

import com.vpp.booking.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, UUID> {

    List<Vehicle> findByCurrentZone(String currentZone);

    List<Vehicle> findByStatus(Vehicle.VehicleStatus status);
}

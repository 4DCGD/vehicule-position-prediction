package com.vpp.booking.repository;

import com.vpp.booking.model.Booking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface BookingRepository extends JpaRepository<Booking, UUID> {

    List<Booking> findByPickupZoneOrderByPickupTimeDesc(String pickupZone);

    Page<Booking> findAll(Pageable pageable);

    @Query("""
        SELECT b.pickupZone, COUNT(b), SUM(b.revenueUsd)
        FROM Booking b
        WHERE b.pickupTime >= :since AND b.status = 'COMPLETED'
        GROUP BY b.pickupZone
        ORDER BY SUM(b.revenueUsd) DESC
    """)
    List<Object[]> revenueByZoneSince(OffsetDateTime since);
}

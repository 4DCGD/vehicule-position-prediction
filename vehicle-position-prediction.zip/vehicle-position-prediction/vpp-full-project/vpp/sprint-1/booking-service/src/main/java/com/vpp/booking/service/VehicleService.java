package com.vpp.booking.service;

import com.vpp.booking.model.Vehicle;
import com.vpp.booking.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class VehicleService {

    private final VehicleRepository repo;

    public List<Vehicle> findAll() {
        return repo.findAll();
    }

    public Optional<Vehicle> findById(UUID id) {
        return repo.findById(id);
    }

    public List<Vehicle> findByZone(String zone) {
        return repo.findByCurrentZone(zone);
    }

    public List<Vehicle> findAvailable() {
        return repo.findByStatus(Vehicle.VehicleStatus.AVAILABLE);
    }
}

package com.vpp.booking.service;

import com.vpp.booking.model.Booking;
import com.vpp.booking.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository repo;

    private static final List<String> ZONES = List.of(
            "IST-001","IST-002","IST-003","IST-004","IST-005","IST-006");

    public List<Booking> findAll(int page, int size) {
        return repo.findAll(PageRequest.of(page, size)).getContent();
    }

    public Optional<Booking> findById(UUID id) {
        return repo.findById(id);
    }

    @Cacheable(value = "bookings-by-zone", key = "#zone")
    public List<Booking> findByPickupZone(String zone) {
        return repo.findByPickupZoneOrderByPickupTimeDesc(zone);
    }

    @Transactional
    public Booking create(Booking booking) {
        booking.setStatus(Booking.BookingStatus.PENDING);
        return repo.save(booking);
    }

    @Transactional
    public Optional<Booking> complete(UUID id) {
        return repo.findById(id).map(b -> {
            b.setStatus(Booking.BookingStatus.COMPLETED);
            b.setDropoffTime(OffsetDateTime.now());
            return repo.save(b);
        });
    }

    @Transactional
    public int seedMockBookings(int count) {
        Random rng = new Random();
        List<Booking> bookings = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String pickup  = ZONES.get(rng.nextInt(ZONES.size()));
            String dropoff = ZONES.get(rng.nextInt(ZONES.size()));
            OffsetDateTime start = OffsetDateTime.now().minusDays(rng.nextInt(30));

            bookings.add(Booking.builder()
                .vehicleId(UUID.randomUUID())
                .userId(UUID.randomUUID())
                .pickupZone(pickup)
                .dropoffZone(dropoff)
                .pickupTime(start)
                .dropoffTime(start.plusMinutes(15 + rng.nextInt(60)))
                .revenueUsd(BigDecimal.valueOf(5 + rng.nextDouble() * 45))
                .distanceKm(BigDecimal.valueOf(1 + rng.nextDouble() * 20))
                .status(Booking.BookingStatus.COMPLETED)
                .build());
        }
        repo.saveAll(bookings);
        return bookings.size();
    }
}

package com.vpp.booking.controller;

import com.vpp.booking.model.Vehicle;
import com.vpp.booking.service.VehicleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/vehicles")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @GetMapping
    public List<Vehicle> listAll() {
        return vehicleService.findAll();
    }

    @GetMapping("/available")
    public List<Vehicle> listAvailable() {
        return vehicleService.findAvailable();
    }

    @GetMapping("/zone/{zone}")
    public List<Vehicle> byZone(@PathVariable String zone) {
        return vehicleService.findByZone(zone);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vehicle> getById(@PathVariable UUID id) {
        return vehicleService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}

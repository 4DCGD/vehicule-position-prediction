package com.vpp.booking.controller;

import com.vpp.booking.model.Booking;
import com.vpp.booking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    @GetMapping
    public List<Booking> listAll(
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {
        return bookingService.findAll(page, size);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> getById(@PathVariable UUID id) {
        return bookingService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/zone/{zone}")
    public List<Booking> byZone(@PathVariable String zone) {
        return bookingService.findByPickupZone(zone);
    }

    @PostMapping
    public ResponseEntity<Booking> create(@RequestBody Booking booking) {
        return ResponseEntity.ok(bookingService.create(booking));
    }

    @PatchMapping("/{id}/complete")
    public ResponseEntity<Booking> complete(@PathVariable UUID id) {
        return bookingService.complete(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /** Seed endpoint – generates 50 mock bookings for dev/testing */
    @PostMapping("/seed")
    public ResponseEntity<String> seed() {
        int count = bookingService.seedMockBookings(50);
        return ResponseEntity.ok("Seeded " + count + " bookings");
    }
}

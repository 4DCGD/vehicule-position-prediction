package com.vpp.booking.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "bookings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "vehicle_id", nullable = false)
    private UUID vehicleId;

    @Column(name = "user_id")
    private UUID userId;

    @Column(name = "pickup_zone", nullable = false, length = 20)
    private String pickupZone;

    @Column(name = "dropoff_zone", length = 20)
    private String dropoffZone;

    @Column(name = "pickup_time", nullable = false)
    private OffsetDateTime pickupTime;

    @Column(name = "dropoff_time")
    private OffsetDateTime dropoffTime;

    @Column(name = "revenue_usd", precision = 10, scale = 2)
    private BigDecimal revenueUsd;

    @Column(name = "distance_km", precision = 8, scale = 3)
    private BigDecimal distanceKm;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 20)
    private BookingStatus status = BookingStatus.PENDING;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    public enum BookingStatus {
        PENDING, ACTIVE, COMPLETED, CANCELLED
    }
}

"""
Sprint 1 – GPS Ingestion Consumer
Reads GPS events from Redpanda/Kafka, writes to PostgreSQL and MinIO (raw lake).
"""

import json
import logging
import os
import io
from datetime import datetime, timezone
from uuid import UUID

import psycopg2
import psycopg2.extras
from confluent_kafka import Consumer, KafkaError
from minio import Minio
from minio.error import S3Error

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────
KAFKA_BROKERS   = os.getenv("KAFKA_BROKERS",   "localhost:9092")
KAFKA_TOPIC     = os.getenv("KAFKA_TOPIC",     "gps.events")
KAFKA_GROUP     = os.getenv("KAFKA_GROUP",     "gps-ingestion-v1")

PG_DSN          = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")

MINIO_ENDPOINT  = os.getenv("MINIO_ENDPOINT",  "localhost:9000")
MINIO_ACCESS    = os.getenv("MINIO_ACCESS",    "vpp_admin")
MINIO_SECRET    = os.getenv("MINIO_SECRET",    "vpp_secret123")
MINIO_BUCKET    = os.getenv("MINIO_BUCKET",    "raw-gps")

BATCH_SIZE      = int(os.getenv("BATCH_SIZE",  "100"))

# ── Clients ───────────────────────────────────────────────────
def make_kafka_consumer() -> Consumer:
    return Consumer({
        "bootstrap.servers": KAFKA_BROKERS,
        "group.id":          KAFKA_GROUP,
        "auto.offset.reset": "earliest",
        "enable.auto.commit": False,
    })

def make_pg_conn():
    conn = psycopg2.connect(PG_DSN)
    conn.autocommit = False
    psycopg2.extras.register_uuid()
    return conn

def make_minio_client() -> Minio:
    client = Minio(MINIO_ENDPOINT, access_key=MINIO_ACCESS,
                   secret_key=MINIO_SECRET, secure=False)
    if not client.bucket_exists(MINIO_BUCKET):
        client.make_bucket(MINIO_BUCKET)
        log.info("Created MinIO bucket: %s", MINIO_BUCKET)
    return client

# ── DB insert ─────────────────────────────────────────────────
INSERT_GPS = """
INSERT INTO gps_events (vehicle_id, lat, lng, speed_kmh, heading_deg, recorded_at)
VALUES %s
ON CONFLICT DO NOTHING
"""

def flush_to_postgres(conn, batch: list[dict]):
    rows = [
        (
            event["vehicle_id"],
            event["lat"],
            event["lng"],
            event.get("speed_kmh"),
            event.get("heading_deg"),
            datetime.fromtimestamp(event["ts"], tz=timezone.utc),
        )
        for event in batch
    ]
    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, INSERT_GPS, rows)
    conn.commit()
    log.info("Flushed %d GPS rows to PostgreSQL", len(rows))

# ── MinIO archive ─────────────────────────────────────────────
def archive_to_minio(minio: Minio, batch: list[dict], ts: datetime):
    key = f"year={ts.year}/month={ts.month:02d}/day={ts.day:02d}/{ts.hour:02d}{ts.minute:02d}{ts.second:02d}.ndjson"
    payload = "\n".join(json.dumps(e) for e in batch).encode()
    minio.put_object(
        MINIO_BUCKET, key,
        io.BytesIO(payload), length=len(payload),
        content_type="application/x-ndjson"
    )
    log.info("Archived %d events to MinIO: %s", len(batch), key)

# ── Main loop ─────────────────────────────────────────────────
def run():
    consumer = make_kafka_consumer()
    pg_conn  = make_pg_conn()
    minio    = make_minio_client()

    consumer.subscribe([KAFKA_TOPIC])
    log.info("Subscribed to topic: %s", KAFKA_TOPIC)

    batch: list[dict] = []

    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            if msg is None:
                if batch:
                    _flush(consumer, pg_conn, minio, batch)
                    batch = []
                continue

            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue
                log.error("Kafka error: %s", msg.error())
                continue

            try:
                event = json.loads(msg.value().decode("utf-8"))
                batch.append(event)
            except (json.JSONDecodeError, KeyError) as e:
                log.warning("Malformed message skipped: %s", e)
                continue

            if len(batch) >= BATCH_SIZE:
                _flush(consumer, pg_conn, minio, batch)
                batch = []

    except KeyboardInterrupt:
        log.info("Shutting down gracefully…")
    finally:
        if batch:
            _flush(consumer, pg_conn, minio, batch)
        consumer.close()
        pg_conn.close()


def _flush(consumer, pg_conn, minio, batch):
    now = datetime.now(tz=timezone.utc)
    try:
        flush_to_postgres(pg_conn, batch)
        archive_to_minio(minio, batch, now)
        consumer.commit()
    except Exception as e:
        log.error("Flush failed, rolling back: %s", e)
        pg_conn.rollback()


if __name__ == "__main__":
    run()

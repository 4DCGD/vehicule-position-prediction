"""
Sprint 1 – Mock GPS Producer
Simulates 10 vehicles moving around Istanbul, publishing to Redpanda/Kafka.
"""

import json
import random
import time
import os
from datetime import datetime, timezone
from uuid import uuid4

import psycopg2
from confluent_kafka import Producer

KAFKA_BROKERS = os.getenv("KAFKA_BROKERS", "localhost:9092")
KAFKA_TOPIC   = os.getenv("KAFKA_TOPIC",   "gps.events")
INTERVAL_SEC  = float(os.getenv("INTERVAL_SEC", "2"))
PG_DSN        = os.getenv("PG_DSN", "postgresql://vpp:vpp_secret@localhost:5432/vpp")

# Istanbul bounding box
LAT_MIN, LAT_MAX = 40.97, 41.12
LNG_MIN, LNG_MAX = 28.89, 29.10

ZONE_CENTERS = {
    "IST-001": (41.042, 28.985),
    "IST-002": (41.065, 28.995),
    "IST-003": (40.990, 29.035),
    "IST-004": (41.050, 29.015),
    "IST-005": (41.022, 29.025),
    "IST-006": (41.022, 28.945),
}


def load_vehicles_from_db() -> list[dict]:
    """Load fleet from PostgreSQL; fall back to random UUIDs if DB unavailable."""
    try:
        conn = psycopg2.connect(PG_DSN)
        with conn.cursor() as cur:
            cur.execute("SELECT id::text, current_zone FROM vehicles")
            rows = cur.fetchall()
        conn.close()
        if rows:
            return [{"id": r[0], "zone": r[1]} for r in rows]
    except Exception as e:
        print(f"DB unavailable ({e}), using random vehicle IDs")
    return [{"id": str(uuid4()), "zone": None} for _ in range(10)]


VEHICLES = load_vehicles_from_db()

# Simulated positions
def _initial_position(vehicle: dict) -> dict:
    zone = vehicle.get("zone")
    if zone and zone in ZONE_CENTERS:
        lat, lng = ZONE_CENTERS[zone]
        return {"lat": lat + random.uniform(-0.01, 0.01),
                "lng": lng + random.uniform(-0.01, 0.01)}
    return {"lat": random.uniform(LAT_MIN, LAT_MAX),
            "lng": random.uniform(LNG_MIN, LNG_MAX)}


positions = {v["id"]: _initial_position(v) for v in VEHICLES}

def delivery_report(err, msg):
    if err:
        print(f"Delivery failed: {err}")

def move(pos: dict) -> dict:
    """Nudge position slightly to simulate movement."""
    return {
        "lat": max(LAT_MIN, min(LAT_MAX, pos["lat"] + random.uniform(-0.002, 0.002))),
        "lng": max(LNG_MIN, min(LNG_MAX, pos["lng"] + random.uniform(-0.002, 0.002))),
    }

def run():
    producer = Producer({"bootstrap.servers": KAFKA_BROKERS})
    print(f"Publishing GPS events to {KAFKA_TOPIC} every {INTERVAL_SEC}s …")

    while True:
        for vehicle in VEHICLES:
            vehicle_id = vehicle["id"]
            positions[vehicle_id] = move(positions[vehicle_id])
            event = {
                "vehicle_id": vehicle_id,
                "lat":        round(positions[vehicle_id]["lat"], 6),
                "lng":        round(positions[vehicle_id]["lng"], 6),
                "speed_kmh":  round(random.uniform(0, 80), 1),
                "heading_deg":round(random.uniform(0, 360), 1),
                "ts":         datetime.now(tz=timezone.utc).timestamp(),
            }
            producer.produce(
                KAFKA_TOPIC,
                key=vehicle_id,
                value=json.dumps(event).encode(),
                callback=delivery_report,
            )
        producer.poll(0)
        time.sleep(INTERVAL_SEC)

if __name__ == "__main__":
    run()

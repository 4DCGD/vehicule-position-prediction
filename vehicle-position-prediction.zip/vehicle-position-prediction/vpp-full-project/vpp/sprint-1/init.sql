-- ============================================================
--  VPP – Database Schema  (PostGIS enabled)
-- ============================================================
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Zones ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS zones (
    id          SERIAL PRIMARY KEY,
    zone_code   VARCHAR(20) UNIQUE NOT NULL,
    name        VARCHAR(100),
    city        VARCHAR(60) DEFAULT 'Istanbul',
    geom        GEOMETRY(Polygon, 4326),
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_zones_geom ON zones USING GIST(geom);

-- ── Vehicles ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS vehicles (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plate         VARCHAR(20) UNIQUE NOT NULL,
    model         VARCHAR(100),
    status        VARCHAR(20) DEFAULT 'AVAILABLE'
                    CHECK (status IN ('AVAILABLE','BOOKED','RELOCATING','MAINTENANCE')),
    current_zone  VARCHAR(20) REFERENCES zones(zone_code),
    battery_pct   SMALLINT,
    last_seen_at  TIMESTAMPTZ DEFAULT NOW(),
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Bookings ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookings (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id    UUID REFERENCES vehicles(id),
    user_id       UUID,
    pickup_zone   VARCHAR(20) REFERENCES zones(zone_code),
    dropoff_zone  VARCHAR(20) REFERENCES zones(zone_code),
    pickup_time   TIMESTAMPTZ NOT NULL,
    dropoff_time  TIMESTAMPTZ,
    revenue_usd   NUMERIC(10,2),
    distance_km   NUMERIC(8,3),
    status        VARCHAR(20) DEFAULT 'PENDING'
                    CHECK (status IN ('PENDING','ACTIVE','COMPLETED','CANCELLED')),
    created_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bookings_vehicle ON bookings(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_bookings_pickup  ON bookings(pickup_zone, pickup_time DESC);

-- ── GPS events (partitioned by month) ────────────────────────
CREATE TABLE IF NOT EXISTS gps_events (
    id           BIGSERIAL,
    vehicle_id   UUID NOT NULL,
    lat          DOUBLE PRECISION NOT NULL,
    lng          DOUBLE PRECISION NOT NULL,
    speed_kmh    FLOAT,
    heading_deg  FLOAT,
    recorded_at  TIMESTAMPTZ NOT NULL,
    geom         GEOMETRY(Point, 4326)
                   GENERATED ALWAYS AS (ST_SetSRID(ST_MakePoint(lng, lat), 4326)) STORED,
    PRIMARY KEY (id, recorded_at)
) PARTITION BY RANGE (recorded_at);

CREATE TABLE gps_2024_q1 PARTITION OF gps_events FOR VALUES FROM ('2024-01-01') TO ('2024-04-01');
CREATE TABLE gps_2024_q2 PARTITION OF gps_events FOR VALUES FROM ('2024-04-01') TO ('2024-07-01');
CREATE TABLE gps_2024_q3 PARTITION OF gps_events FOR VALUES FROM ('2024-07-01') TO ('2024-10-01');
CREATE TABLE gps_2024_q4 PARTITION OF gps_events FOR VALUES FROM ('2024-10-01') TO ('2025-01-01');
CREATE TABLE gps_2025_q1 PARTITION OF gps_events FOR VALUES FROM ('2025-01-01') TO ('2025-04-01');
CREATE TABLE gps_2025_q2 PARTITION OF gps_events FOR VALUES FROM ('2025-04-01') TO ('2025-07-01');

CREATE INDEX idx_gps_vehicle_time ON gps_events(vehicle_id, recorded_at DESC);
CREATE INDEX idx_gps_geom         ON gps_events USING GIST(geom);

-- ── ML predictions (output store) ────────────────────────────
CREATE TABLE IF NOT EXISTS zone_demand_predictions (
    id            BIGSERIAL PRIMARY KEY,
    zone_code     VARCHAR(20) REFERENCES zones(zone_code),
    horizon_hours SMALLINT NOT NULL CHECK (horizon_hours IN (2,6,24)),
    predicted_at  TIMESTAMPTZ NOT NULL,
    forecast_for  TIMESTAMPTZ NOT NULL,
    demand_score  NUMERIC(6,3),
    confidence    NUMERIC(5,3),
    model_version VARCHAR(50),
    created_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_pred_zone_horizon ON zone_demand_predictions(zone_code, horizon_hours, forecast_for DESC);

-- ── Seed zones (Istanbul) ─────────────────────────────────────
INSERT INTO zones (zone_code, name, geom) VALUES
  ('IST-001','Beyoglu',  ST_GeomFromText('POLYGON((28.970 41.030,29.000 41.030,29.000 41.055,28.970 41.055,28.970 41.030))',4326)),
  ('IST-002','Sisli',    ST_GeomFromText('POLYGON((28.980 41.055,29.010 41.055,29.010 41.075,28.980 41.075,28.980 41.055))',4326)),
  ('IST-003','Kadikoy',  ST_GeomFromText('POLYGON((29.020 40.980,29.050 40.980,29.050 41.000,29.020 41.000,29.020 40.980))',4326)),
  ('IST-004','Besiktas', ST_GeomFromText('POLYGON((29.000 41.040,29.030 41.040,29.030 41.060,29.000 41.060,29.000 41.040))',4326)),
  ('IST-005','Uskudar',  ST_GeomFromText('POLYGON((29.010 41.010,29.040 41.010,29.040 41.035,29.010 41.035,29.010 41.010))',4326)),
  ('IST-006','Fatih',    ST_GeomFromText('POLYGON((28.930 41.010,28.960 41.010,28.960 41.035,28.930 41.035,28.930 41.010))',4326))
ON CONFLICT DO NOTHING;

-- ── Seed vehicles (10 fleet units across Istanbul zones) ─────
INSERT INTO vehicles (plate, model, status, current_zone, battery_pct) VALUES
  ('34 VPP 01', 'Tesla Model 3',   'AVAILABLE', 'IST-001', 87),
  ('34 VPP 02', 'Tesla Model 3',   'AVAILABLE', 'IST-001', 72),
  ('34 VPP 03', 'Renault Zoe',     'AVAILABLE', 'IST-002', 91),
  ('34 VPP 04', 'Renault Zoe',     'BOOKED',    'IST-002', 45),
  ('34 VPP 05', 'Nissan Leaf',     'AVAILABLE', 'IST-003', 68),
  ('34 VPP 06', 'Nissan Leaf',     'AVAILABLE', 'IST-003', 55),
  ('34 VPP 07', 'Tesla Model Y',   'AVAILABLE', 'IST-004', 93),
  ('34 VPP 08', 'Tesla Model Y',   'RELOCATING','IST-004', 78),
  ('34 VPP 09', 'Hyundai Kona EV', 'AVAILABLE', 'IST-005', 82),
  ('34 VPP 10', 'Hyundai Kona EV', 'AVAILABLE', 'IST-006', 61)
ON CONFLICT (plate) DO NOTHING;

-- ── dbt mart schema (created upfront for feature pipeline) ───
CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS marts;

# Vehicle Position Prediction (VPP)

> **Where should each vehicle be in the next 2, 6, and 24 hours to maximise revenue?**

---

## Project Structure

```
vpp/
├── sprint-1/                     # Infrastructure & Data Ingestion
│   ├── docker-compose.yml        # Postgres+PostGIS, Redis, Redpanda, MinIO, MLflow
│   ├── init.sql                  # DB schema + seed zones (Istanbul)
│   ├── booking-service/          # Spring Boot microservice (REST API)
│   └── gps-ingestion/            # Kafka consumer + mock producer (Python)
│
├── sprint-2/                     # Data Transformation & Feature Engineering
│   ├── dbt/                      # dbt models: staging + mart_zone_hourly_demand
│   └── feature-engineering/      # feature_pipeline.py + Feast repo definition
│
├── sprint-3/                     # Model Training & Serving
│   ├── training/train.py         # XGBoost cross-validated training + MLflow logging
│   └── serving/api.py            # FastAPI serving API (2h / 6h / 24h endpoints)
│
├── sprint-4/                     # Decision Engine & Dashboard
│   ├── decision-engine/          # Spring Boot microservice — relocation logic
│   └── dashboard/                # React + Recharts operator dashboard
│
└── sprint-5/                     # Testing & Monitoring
    ├── ab-testing/               # evaluate_models.py — drift detection & metrics
    └── monitoring/               # Prometheus config + Grafana dashboard JSON
```

---

## Quick Start

### Automated setup (Windows)

```powershell
cd vpp-full-project\vpp
.\setup.ps1
```

### Manual setup

#### 1. Bring up infrastructure (Sprint 1)

```bash
cd sprint-1
docker-compose up -d
# Wait ~30 seconds, then verify:
# Postgres:   localhost:5432
# Redpanda:   localhost:9092  (console: localhost:8080)
# MinIO:      localhost:9000  (console: localhost:9001)
# MLflow:     localhost:5000
# Prometheus: localhost:9090
# Grafana:    localhost:3000  (admin / vpp_admin)
```

Create Kafka topic:

```bash
docker exec vpp_redpanda rpk topic create gps.events -p 3
```

#### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

#### 3. Bootstrap data & train models

```bash
python scripts/bootstrap_data.py          # seed 30 days of bookings + build mart
python scripts/export_features.py         # export parquet for training
cd sprint-3/training && python train.py # trains 2h/6h/24h XGBoost models
```

#### 4. Start services (each in a separate terminal)


| Service         | Command                                                | Port |
| --------------- | ------------------------------------------------------ | ---- |
| GPS producer    | `cd sprint-1/gps-ingestion && python producer_mock.py` | —    |
| GPS consumer    | `cd sprint-1/gps-ingestion && python consumer.py`      | —    |
| Booking API     | `cd sprint-1/booking-service && mvn spring-boot:run`   | 8081 |
| Model serving   | `cd sprint-3/serving && uvicorn api:app --port 8000`   | 8000 |
| Decision engine | `cd sprint-4/decision-engine && mvn spring-boot:run`   | 8082 |
| Dashboard       | `cd sprint-4/dashboard && npm install && npm run dev`  | 5173 |


#### 5. Seed additional bookings (optional)

```bash
curl -X POST http://localhost:8081/api/v1/bookings/seed
```

#### 6. Run evaluation (Sprint 5)

```bash
python scripts/store_predictions.py       # persist live predictions to DB
cd sprint-5/ab-testing && python evaluate_models.py
```

### API Endpoints


| API             | Endpoint                             | Description                |
| --------------- | ------------------------------------ | -------------------------- |
| Booking         | `GET /api/v1/vehicles`               | List fleet vehicles        |
| Booking         | `POST /api/v1/bookings/seed`         | Seed mock bookings         |
| Model serving   | `POST /predict/batch`                | Batch demand predictions   |
| Model serving   | `GET /metrics`                       | Prometheus metrics         |
| Decision engine | `POST /api/v1/decisions/relocations` | Relocation recommendations |
| Dashboard       | `http://localhost:5173`              | Operator UI                |


---

## Technology Stack


| Layer               | Technology                  |
| ------------------- | --------------------------- |
| Operational DB      | PostgreSQL 15 + PostGIS     |
| Cache               | Redis 7                     |
| Event Streaming     | Redpanda (Kafka-compatible) |
| Object Storage      | MinIO (S3-compatible)       |
| Booking API         | Spring Boot 3 + JPA         |
| GPS Ingestion       | Python + confluent-kafka    |
| Data Transformation | dbt                         |
| Feature Store       | Feast                       |
| ML Training         | XGBoost + scikit-learn      |
| Experiment Tracking | MLflow                      |
| Model Serving       | FastAPI                     |
| Decision Engine     | Spring Boot 3               |
| Dashboard           | React 18 + Recharts + Vite  |
| Monitoring          | Prometheus + Grafana        |


---

## Team Principles

1. **Pair programming** across data and operational teams each sprint.
2. **Mentorship** on MLflow, Feast, and PostGIS for juniors.
3. **Iterative review** at end of each sprint — adjust scope as needed.

